// 
// Decompiled by Procyon v0.5.36
// 

package net.mcreator.tobaccoproducts.keybind;

import net.minecraftforge.fml.network.NetworkEvent;
import java.util.function.Supplier;
import net.minecraft.network.PacketBuffer;
import net.minecraft.world.World;
import net.mcreator.tobaccoproducts.procedures.CigaretteClickProcProcedure;
import java.util.HashMap;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraft.entity.player.PlayerEntity;
import net.mcreator.tobaccoproducts.SmokingmodMod;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraft.client.settings.KeyBinding;
import net.mcreator.tobaccoproducts.SmokingmodModElements.ModElement;
import net.mcreator.tobaccoproducts.SmokingmodModElements;

@Tag
public class CigaretteClickKeyBinding extends SmokingmodModElements.ModElement
{
    @OnlyIn(Dist.CLIENT)
    private KeyBinding keys;
    
    public CigaretteClickKeyBinding(final SmokingmodModElements instance) {
        super(instance, 170);
        this.elements.addNetworkMessage(KeyBindingPressedMessage.class, KeyBindingPressedMessage::buffer, KeyBindingPressedMessage::new, KeyBindingPressedMessage::handler);
    }
    
    @OnlyIn(Dist.CLIENT)
    @Override
    public void initElements() {
        ClientRegistry.registerKeyBinding(this.keys = new KeyBinding("key.mcreator.cigarette_click", 75, "key.categories.misc"));
        MinecraftForge.EVENT_BUS.register((Object)this);
    }
    
    @SubscribeEvent
    @OnlyIn(Dist.CLIENT)
    public void onKeyInput(final InputEvent.KeyInputEvent event) {
        if (Minecraft.func_71410_x().field_71462_r == null && event.getKey() == this.keys.getKey().func_197937_c() && event.getAction() == 1) {
            SmokingmodMod.PACKET_HANDLER.sendToServer((Object)new KeyBindingPressedMessage(0, 0));
            pressAction((PlayerEntity)Minecraft.func_71410_x().field_71439_g, 0, 0);
        }
    }
    
    private static void pressAction(final PlayerEntity entity, final int type, final int pressedms) {
        final World world = entity.field_70170_p;
        final int x = (int)entity.func_226277_ct_();
        final int y = (int)entity.func_226278_cu_();
        final int z = (int)entity.func_226281_cx_();
        if (!world.func_175667_e(new BlockPos(x, y, z))) {
            return;
        }
        if (type == 0) {
            final HashMap<String, Object> $_dependencies = new HashMap<String, Object>();
            $_dependencies.put("world", world);
            CigaretteClickProcProcedure.executeProcedure($_dependencies);
        }
    }
    
    public static class KeyBindingPressedMessage
    {
        int type;
        int pressedms;
        
        public KeyBindingPressedMessage(final int type, final int pressedms) {
            this.type = type;
            this.pressedms = pressedms;
        }
        
        public KeyBindingPressedMessage(final PacketBuffer buffer) {
            this.type = buffer.readInt();
            this.pressedms = buffer.readInt();
        }
        
        public static void buffer(final KeyBindingPressedMessage message, final PacketBuffer buffer) {
            buffer.writeInt(message.type);
            buffer.writeInt(message.pressedms);
        }
        
        public static void handler(final KeyBindingPressedMessage message, final Supplier<NetworkEvent.Context> contextSupplier) {
            final NetworkEvent.Context context = contextSupplier.get();
            context.enqueueWork(() -> pressAction((PlayerEntity)context.getSender(), message.type, message.pressedms));
            context.setPacketHandled(true);
        }
    }
}
