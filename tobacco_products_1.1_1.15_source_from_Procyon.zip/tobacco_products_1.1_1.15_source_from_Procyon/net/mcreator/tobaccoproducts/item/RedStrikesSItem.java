// 
// Decompiled by Procyon v0.5.36
// 

package net.mcreator.tobaccoproducts.item;

import net.mcreator.tobaccoproducts.procedures.RedStrikesSPProcedure;
import net.minecraft.util.IItemProvider;
import net.minecraft.block.Blocks;
import net.minecraftforge.fml.network.NetworkHooks;
import net.minecraft.network.IPacket;
import net.minecraftforge.fml.network.FMLPlayMessages;
import net.minecraft.entity.IRendersAsItem;
import net.mcreator.tobaccoproducts.procedures.RedStrikesSmokeProcedure;
import java.util.HashMap;
import net.minecraft.entity.projectile.AbstractArrowEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.item.UseAction;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;
import net.minecraft.client.renderer.entity.SpriteRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererManager;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraft.util.SoundEvent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.Entity;
import java.util.Random;
import net.minecraft.entity.LivingEntity;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import java.util.function.BiFunction;
import net.minecraft.entity.EntityClassification;
import net.minecraft.entity.EntityType;
import net.minecraftforge.registries.ObjectHolder;
import net.minecraft.item.Item;
import net.mcreator.tobaccoproducts.SmokingmodModElements.ModElement;
import net.mcreator.tobaccoproducts.SmokingmodModElements;

@Tag
public class RedStrikesSItem extends SmokingmodModElements.ModElement
{
    @ObjectHolder("smokingmod:red_strikes_s")
    public static final Item block;
    @ObjectHolder("smokingmod:entitybulletred_strikes_s")
    public static final EntityType arrow;
    
    public RedStrikesSItem(final SmokingmodModElements instance) {
        super(instance, 404);
    }
    
    @Override
    public void initElements() {
        this.elements.items.add(() -> new ItemRanged());
        this.elements.entities.add(() -> (EntityType)EntityType.Builder.func_220322_a(ArrowCustomEntity::new, EntityClassification.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).setCustomClientFactory((BiFunction)ArrowCustomEntity::new).func_220321_a(0.5f, 0.5f).func_206830_a("entitybulletred_strikes_s").setRegistryName("entitybulletred_strikes_s"));
    }
    
    @OnlyIn(Dist.CLIENT)
    @Override
    public void init(final FMLCommonSetupEvent event) {
        RenderingRegistry.registerEntityRenderingHandler(RedStrikesSItem.arrow, renderManager -> new SpriteRenderer(renderManager, Minecraft.func_71410_x().func_175599_af()));
    }
    
    public static ArrowCustomEntity shoot(final World world, final LivingEntity entity, final Random random, final float power, final double damage, final int knockback) {
        final ArrowCustomEntity entityarrow = new ArrowCustomEntity((EntityType<? extends ArrowCustomEntity>)RedStrikesSItem.arrow, entity, world);
        entityarrow.func_70186_c(entity.func_70040_Z().field_72450_a, entity.func_70040_Z().field_72448_b, entity.func_70040_Z().field_72449_c, power * 2.0f, 0.0f);
        entityarrow.func_174810_b(true);
        entityarrow.func_70243_d(false);
        entityarrow.func_70239_b(damage);
        entityarrow.func_70240_a(knockback);
        world.func_217376_c((Entity)entityarrow);
        final int x = (int)entity.func_226277_ct_();
        final int y = (int)entity.func_226278_cu_();
        final int z = (int)entity.func_226281_cx_();
        world.func_184148_a((PlayerEntity)null, (double)x, (double)y, (double)z, (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("")), SoundCategory.PLAYERS, 1.0f, 1.0f / (random.nextFloat() * 0.5f + 1.0f) + power / 2.0f);
        return entityarrow;
    }
    
    public static ArrowCustomEntity shoot(final LivingEntity entity, final LivingEntity target) {
        final ArrowCustomEntity entityarrow = new ArrowCustomEntity((EntityType<? extends ArrowCustomEntity>)RedStrikesSItem.arrow, entity, entity.field_70170_p);
        final double d0 = target.func_226278_cu_() + target.func_70047_e() - 1.1;
        final double d2 = target.func_226277_ct_() - entity.func_226277_ct_();
        final double d3 = target.func_226281_cx_() - entity.func_226281_cx_();
        entityarrow.func_70186_c(d2, d0 - entityarrow.func_226278_cu_() + MathHelper.func_76133_a(d2 * d2 + d3 * d3) * 0.20000000298023224, d3, 1.6f, 12.0f);
        entityarrow.func_174810_b(true);
        entityarrow.func_70243_d(false);
        entity.field_70170_p.func_217376_c((Entity)entityarrow);
        final int x = (int)entity.func_226277_ct_();
        final int y = (int)entity.func_226278_cu_();
        final int z = (int)entity.func_226281_cx_();
        entity.field_70170_p.func_184148_a((PlayerEntity)null, (double)x, (double)y, (double)z, (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("")), SoundCategory.PLAYERS, 1.0f, 1.0f / (new Random().nextFloat() * 0.5f + 1.0f));
        return entityarrow;
    }
    
    static {
        block = null;
        arrow = null;
    }
    
    public static class ItemRanged extends Item
    {
        public ItemRanged() {
            super(new Item.Properties().func_200916_a((ItemGroup)null).func_200918_c(11));
            this.setRegistryName("red_strikes_s");
        }
        
        public UseAction func_77661_b(final ItemStack stack) {
            return UseAction.BOW;
        }
        
        public ActionResult<ItemStack> func_77659_a(final World world, final PlayerEntity entity, final Hand hand) {
            entity.func_184598_c(hand);
            return (ActionResult<ItemStack>)new ActionResult(ActionResultType.SUCCESS, (Object)entity.func_184586_b(hand));
        }
        
        public int func_77626_a(final ItemStack itemstack) {
            return 72000;
        }
        
        public void func_77615_a(final ItemStack itemstack, final World world, final LivingEntity entityLiving, final int timeLeft) {
            if (!world.field_72995_K && entityLiving instanceof ServerPlayerEntity) {
                final ServerPlayerEntity entity = (ServerPlayerEntity)entityLiving;
                final ArrowCustomEntity entityarrow = RedStrikesSItem.shoot(world, (LivingEntity)entity, ItemRanged.field_77697_d, 0.3f, 0.0, 0);
                itemstack.func_222118_a(1, (LivingEntity)entity, e -> e.func_213334_d(entity.func_184600_cs()));
                entityarrow.field_70251_a = AbstractArrowEntity.PickupStatus.DISALLOWED;
                final int x = (int)entity.func_226277_ct_();
                final int y = (int)entity.func_226278_cu_();
                final int z = (int)entity.func_226281_cx_();
                final HashMap<String, Object> $_dependencies = new HashMap<String, Object>();
                $_dependencies.put("entity", entity);
                $_dependencies.put("itemstack", itemstack);
                $_dependencies.put("world", world);
                RedStrikesSmokeProcedure.executeProcedure($_dependencies);
            }
        }
    }
    
    @OnlyIn(value = Dist.CLIENT, _interface = IRendersAsItem.class)
    public static class ArrowCustomEntity extends AbstractArrowEntity implements IRendersAsItem
    {
        public ArrowCustomEntity(final FMLPlayMessages.SpawnEntity packet, final World world) {
            super(RedStrikesSItem.arrow, world);
        }
        
        public ArrowCustomEntity(final EntityType<? extends ArrowCustomEntity> type, final World world) {
            super((EntityType)type, world);
        }
        
        public ArrowCustomEntity(final EntityType<? extends ArrowCustomEntity> type, final double x, final double y, final double z, final World world) {
            super((EntityType)type, x, y, z, world);
        }
        
        public ArrowCustomEntity(final EntityType<? extends ArrowCustomEntity> type, final LivingEntity entity, final World world) {
            super((EntityType)type, entity, world);
        }
        
        public IPacket<?> func_213297_N() {
            return (IPacket<?>)NetworkHooks.getEntitySpawningPacket((Entity)this);
        }
        
        @OnlyIn(Dist.CLIENT)
        public ItemStack func_184543_l() {
            return new ItemStack((IItemProvider)Blocks.field_150350_a, 1);
        }
        
        protected ItemStack func_184550_j() {
            return null;
        }
        
        protected void func_184548_a(final LivingEntity entity) {
            super.func_184548_a(entity);
            entity.func_85034_r(entity.func_85035_bI() - 1);
        }
        
        public void func_70071_h_() {
            super.func_70071_h_();
            final int x = (int)this.func_226277_ct_();
            final int y = (int)this.func_226278_cu_();
            final int z = (int)this.func_226281_cx_();
            final World world = this.field_70170_p;
            final Entity entity = this.func_212360_k();
            final HashMap<String, Object> $_dependencies = new HashMap<String, Object>();
            $_dependencies.put("x", x);
            $_dependencies.put("y", y);
            $_dependencies.put("z", z);
            $_dependencies.put("world", world);
            RedStrikesSPProcedure.executeProcedure($_dependencies);
            if (this.field_70254_i) {
                this.func_70106_y();
            }
        }
    }
}
