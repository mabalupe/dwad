// 
// Decompiled by Procyon v0.5.36
// 

package net.mcreator.tobaccoproducts.item;

import net.minecraft.block.BlockState;
import net.minecraft.item.ItemStack;
import net.mcreator.tobaccoproducts.itemgroup.TobaccoItemGroup;
import net.minecraftforge.registries.ObjectHolder;
import net.minecraft.item.Item;
import net.mcreator.tobaccoproducts.SmokingmodModElements.ModElement;
import net.mcreator.tobaccoproducts.SmokingmodModElements;

@Tag
public class BurleyVirginiaDarkCakeItem extends SmokingmodModElements.ModElement
{
    @ObjectHolder("smokingmod:burley_virginia_dark_cake")
    public static final Item block;
    
    public BurleyVirginiaDarkCakeItem(final SmokingmodModElements instance) {
        super(instance, 20);
    }
    
    @Override
    public void initElements() {
        this.elements.items.add(() -> new ItemCustom());
    }
    
    static {
        block = null;
    }
    
    public static class ItemCustom extends Item
    {
        public ItemCustom() {
            super(new Item.Properties().func_200916_a(TobaccoItemGroup.tab).func_200917_a(32));
            this.setRegistryName("burley_virginia_dark_cake");
        }
        
        public int func_77619_b() {
            return 0;
        }
        
        public int func_77626_a(final ItemStack itemstack) {
            return 0;
        }
        
        public float func_150893_a(final ItemStack par1ItemStack, final BlockState par2Block) {
            return 1.0f;
        }
    }
}
