// 
// Decompiled by Procyon v0.5.36
// 

package net.mcreator.tobaccoproducts.item;

import net.mcreator.tobaccoproducts.procedures.BlackWitherFinestPackClickProcedure;
import java.util.HashMap;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.util.text.ITextComponent;
import java.util.List;
import net.minecraft.world.World;
import net.minecraft.block.BlockState;
import net.minecraft.item.ItemStack;
import net.mcreator.tobaccoproducts.itemgroup.TobaccoItemGroup;
import net.minecraftforge.registries.ObjectHolder;
import net.minecraft.item.Item;
import net.mcreator.tobaccoproducts.SmokingmodModElements.ModElement;
import net.mcreator.tobaccoproducts.SmokingmodModElements;

@Tag
public class BlacWitherFinestPackItem extends SmokingmodModElements.ModElement
{
    @ObjectHolder("smokingmod:blac_wither_finest_pack")
    public static final Item block;
    
    public BlacWitherFinestPackItem(final SmokingmodModElements instance) {
        super(instance, 47);
    }
    
    @Override
    public void initElements() {
        this.elements.items.add(() -> new ItemCustom());
    }
    
    static {
        block = null;
    }
    
    public static class ItemCustom extends Item
    {
        public ItemCustom() {
            super(new Item.Properties().func_200916_a(TobaccoItemGroup.tab).func_200918_c(20));
            this.setRegistryName("blac_wither_finest_pack");
        }
        
        public int func_77619_b() {
            return 0;
        }
        
        public int func_77626_a(final ItemStack itemstack) {
            return 1;
        }
        
        public float func_150893_a(final ItemStack par1ItemStack, final BlockState par2Block) {
            return 2.0f;
        }
        
        public void func_77624_a(final ItemStack itemstack, final World world, final List<ITextComponent> list, final ITooltipFlag flag) {
            super.func_77624_a(itemstack, world, (List)list, flag);
            list.add((ITextComponent)new StringTextComponent("Popular among youth, cigarettes with black paper, chocolate flavour and sweetened tip."));
            list.add((ITextComponent)new StringTextComponent("A pack of 20."));
        }
        
        public ActionResult<ItemStack> func_77659_a(final World world, final PlayerEntity entity, final Hand hand) {
            final ActionResult<ItemStack> ar = (ActionResult<ItemStack>)super.func_77659_a(world, entity, hand);
            final ItemStack itemstack = (ItemStack)ar.func_188398_b();
            final int x = (int)entity.func_226277_ct_();
            final int y = (int)entity.func_226278_cu_();
            final int z = (int)entity.func_226281_cx_();
            final HashMap<String, Object> $_dependencies = new HashMap<String, Object>();
            $_dependencies.put("entity", entity);
            $_dependencies.put("itemstack", itemstack);
            BlackWitherFinestPackClickProcedure.executeProcedure($_dependencies);
            return ar;
        }
    }
}
