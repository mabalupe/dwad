// 
// Decompiled by Procyon v0.5.36
// 

package net.mcreator.tobaccoproducts.item;

import net.minecraft.block.BlockState;
import net.minecraft.item.ItemStack;
import net.mcreator.tobaccoproducts.itemgroup.TobaccoItemGroup;
import net.minecraftforge.registries.ObjectHolder;
import net.minecraft.item.Item;
import net.mcreator.tobaccoproducts.SmokingmodModElements.ModElement;
import net.mcreator.tobaccoproducts.SmokingmodModElements;

@Tag
public class VirginiaLightShagItem extends SmokingmodModElements.ModElement
{
    @ObjectHolder("smokingmod:virginia_light_shag")
    public static final Item block;
    
    public VirginiaLightShagItem(final SmokingmodModElements instance) {
        super(instance, 10);
    }
    
    @Override
    public void initElements() {
        this.elements.items.add(() -> new ItemCustom());
    }
    
    static {
        block = null;
    }
    
    public static class ItemCustom extends Item
    {
        public ItemCustom() {
            super(new Item.Properties().func_200916_a(TobaccoItemGroup.tab).func_200917_a(64));
            this.setRegistryName("virginia_light_shag");
        }
        
        public int func_77619_b() {
            return 0;
        }
        
        public int func_77626_a(final ItemStack itemstack) {
            return 0;
        }
        
        public float func_150893_a(final ItemStack par1ItemStack, final BlockState par2Block) {
            return 1.0f;
        }
    }
}
