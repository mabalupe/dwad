// 
// Decompiled by Procyon v0.5.36
// 

package net.mcreator.tobaccoproducts.item;

import net.minecraft.util.Direction;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.mcreator.tobaccoproducts.procedures.BurleyPlantOnSoilProcedure;
import java.util.HashMap;
import net.minecraft.util.ActionResultType;
import net.minecraft.item.ItemUseContext;
import net.minecraft.block.BlockState;
import net.minecraft.item.ItemStack;
import net.mcreator.tobaccoproducts.itemgroup.TobaccoItemGroup;
import net.minecraftforge.registries.ObjectHolder;
import net.minecraft.item.Item;
import net.mcreator.tobaccoproducts.SmokingmodModElements.ModElement;
import net.mcreator.tobaccoproducts.SmokingmodModElements;

@Tag
public class BurleySeedsItem extends SmokingmodModElements.ModElement
{
    @ObjectHolder("smokingmod:burley_seeds")
    public static final Item block;
    
    public BurleySeedsItem(final SmokingmodModElements instance) {
        super(instance, 2);
    }
    
    @Override
    public void initElements() {
        this.elements.items.add(() -> new ItemCustom());
    }
    
    static {
        block = null;
    }
    
    public static class ItemCustom extends Item
    {
        public ItemCustom() {
            super(new Item.Properties().func_200916_a(TobaccoItemGroup.tab).func_200917_a(64));
            this.setRegistryName("burley_seeds");
        }
        
        public int func_77619_b() {
            return 0;
        }
        
        public int func_77626_a(final ItemStack itemstack) {
            return 0;
        }
        
        public float func_150893_a(final ItemStack par1ItemStack, final BlockState par2Block) {
            return 1.0f;
        }
        
        public ActionResultType onItemUseFirst(final ItemStack stack, final ItemUseContext context) {
            final ActionResultType retval = super.onItemUseFirst(stack, context);
            final World world = context.func_195991_k();
            final BlockPos pos = context.func_195995_a();
            final PlayerEntity entity = context.func_195999_j();
            final Direction direction = context.func_196000_l();
            final int x = pos.func_177958_n();
            final int y = pos.func_177956_o();
            final int z = pos.func_177952_p();
            final ItemStack itemstack = context.func_195996_i();
            final HashMap<String, Object> $_dependencies = new HashMap<String, Object>();
            $_dependencies.put("entity", entity);
            $_dependencies.put("x", x);
            $_dependencies.put("y", y);
            $_dependencies.put("z", z);
            $_dependencies.put("world", world);
            BurleyPlantOnSoilProcedure.executeProcedure($_dependencies);
            return retval;
        }
    }
}
