// 
// Decompiled by Procyon v0.5.36
// 

package net.mcreator.tobaccoproducts.itemgroup;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraft.util.IItemProvider;
import net.mcreator.tobaccoproducts.item.TobaccoLeafItemItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;
import net.mcreator.tobaccoproducts.SmokingmodModElements.ModElement;
import net.mcreator.tobaccoproducts.SmokingmodModElements;

@Tag
public class TobaccoItemGroup extends SmokingmodModElements.ModElement
{
    public static ItemGroup tab;
    
    public TobaccoItemGroup(final SmokingmodModElements instance) {
        super(instance, 99);
    }
    
    @Override
    public void initElements() {
        TobaccoItemGroup.tab = new ItemGroup("tabtobacco") {
            @OnlyIn(Dist.CLIENT)
            public ItemStack func_78016_d() {
                return new ItemStack((IItemProvider)TobaccoLeafItemItem.block, 1);
            }
            
            @OnlyIn(Dist.CLIENT)
            public boolean hasSearchBar() {
                return false;
            }
        };
    }
}
