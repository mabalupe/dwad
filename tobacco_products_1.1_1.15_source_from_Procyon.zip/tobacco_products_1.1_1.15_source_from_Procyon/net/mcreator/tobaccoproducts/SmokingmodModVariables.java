// 
// Decompiled by Procyon v0.5.36
// 

package net.mcreator.tobaccoproducts;

import net.minecraftforge.fml.LogicalSide;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.network.NetworkEvent;
import net.minecraft.network.PacketBuffer;
import net.minecraft.world.dimension.DimensionType;
import net.minecraft.world.server.ServerWorld;
import java.util.function.Supplier;
import net.minecraftforge.fml.network.PacketDistributor;
import net.minecraft.world.World;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.world.storage.WorldSavedData;

public class SmokingmodModVariables
{
    public static class WorldVariables extends WorldSavedData
    {
        public static final String DATA_NAME = "smokingmod_worldvars";
        public double time;
        public double seconds;
        public double extinguish;
        public double smoke_time;
        public boolean smoke;
        public double smoke_num;
        public double click;
        public double smoke_part;
        public double cash;
        static WorldVariables clientSide;
        
        public WorldVariables() {
            super("smokingmod_worldvars");
            this.time = 0.0;
            this.seconds = 0.0;
            this.extinguish = 0.0;
            this.smoke_time = 0.0;
            this.smoke = false;
            this.smoke_num = 0.0;
            this.click = 0.0;
            this.smoke_part = 0.0;
            this.cash = 0.0;
        }
        
        public WorldVariables(final String s) {
            super(s);
            this.time = 0.0;
            this.seconds = 0.0;
            this.extinguish = 0.0;
            this.smoke_time = 0.0;
            this.smoke = false;
            this.smoke_num = 0.0;
            this.click = 0.0;
            this.smoke_part = 0.0;
            this.cash = 0.0;
        }
        
        public void func_76184_a(final CompoundNBT nbt) {
            this.time = nbt.func_74769_h("time");
            this.seconds = nbt.func_74769_h("seconds");
            this.extinguish = nbt.func_74769_h("extinguish");
            this.smoke_time = nbt.func_74769_h("smoke_time");
            this.smoke = nbt.func_74767_n("smoke");
            this.smoke_num = nbt.func_74769_h("smoke_num");
            this.click = nbt.func_74769_h("click");
            this.smoke_part = nbt.func_74769_h("smoke_part");
            this.cash = nbt.func_74769_h("cash");
        }
        
        public CompoundNBT func_189551_b(final CompoundNBT nbt) {
            nbt.func_74780_a("time", this.time);
            nbt.func_74780_a("seconds", this.seconds);
            nbt.func_74780_a("extinguish", this.extinguish);
            nbt.func_74780_a("smoke_time", this.smoke_time);
            nbt.func_74757_a("smoke", this.smoke);
            nbt.func_74780_a("smoke_num", this.smoke_num);
            nbt.func_74780_a("click", this.click);
            nbt.func_74780_a("smoke_part", this.smoke_part);
            nbt.func_74780_a("cash", this.cash);
            return nbt;
        }
        
        public void syncData(final World world) {
            this.func_76185_a();
            if (world.field_72995_K) {
                SmokingmodMod.PACKET_HANDLER.sendToServer((Object)new WorldSavedDataSyncMessage(1, this));
            }
            else {
                SmokingmodMod.PACKET_HANDLER.send(PacketDistributor.DIMENSION.with((Supplier)world.field_73011_w::func_186058_p), (Object)new WorldSavedDataSyncMessage(1, this));
            }
        }
        
        public static WorldVariables get(final World world) {
            if (world instanceof ServerWorld) {
                return (WorldVariables)((ServerWorld)world).func_217481_x().func_215752_a((Supplier)WorldVariables::new, "smokingmod_worldvars");
            }
            return WorldVariables.clientSide;
        }
        
        static {
            WorldVariables.clientSide = new WorldVariables();
        }
    }
    
    public static class MapVariables extends WorldSavedData
    {
        public static final String DATA_NAME = "smokingmod_mapvars";
        public double nicotine_level;
        public double packtobacco;
        public boolean print;
        public double light_pipe;
        public double shop_select;
        public String select_product;
        public double Smokeless;
        public double tick;
        public double sec;
        public double rand_chew_time;
        public double rand_chew_time_pick;
        static MapVariables clientSide;
        
        public MapVariables() {
            super("smokingmod_mapvars");
            this.nicotine_level = 0.0;
            this.packtobacco = 0.0;
            this.print = true;
            this.light_pipe = 0.0;
            this.shop_select = 0.0;
            this.select_product = "Cigarettes";
            this.Smokeless = 0.0;
            this.tick = 0.0;
            this.sec = 0.0;
            this.rand_chew_time = 0.0;
            this.rand_chew_time_pick = 0.0;
        }
        
        public MapVariables(final String s) {
            super(s);
            this.nicotine_level = 0.0;
            this.packtobacco = 0.0;
            this.print = true;
            this.light_pipe = 0.0;
            this.shop_select = 0.0;
            this.select_product = "Cigarettes";
            this.Smokeless = 0.0;
            this.tick = 0.0;
            this.sec = 0.0;
            this.rand_chew_time = 0.0;
            this.rand_chew_time_pick = 0.0;
        }
        
        public void func_76184_a(final CompoundNBT nbt) {
            this.nicotine_level = nbt.func_74769_h("nicotine_level");
            this.packtobacco = nbt.func_74769_h("packtobacco");
            this.print = nbt.func_74767_n("print");
            this.light_pipe = nbt.func_74769_h("light_pipe");
            this.shop_select = nbt.func_74769_h("shop_select");
            this.select_product = nbt.func_74779_i("select_product");
            this.Smokeless = nbt.func_74769_h("Smokeless");
            this.tick = nbt.func_74769_h("tick");
            this.sec = nbt.func_74769_h("sec");
            this.rand_chew_time = nbt.func_74769_h("rand_chew_time");
            this.rand_chew_time_pick = nbt.func_74769_h("rand_chew_time_pick");
        }
        
        public CompoundNBT func_189551_b(final CompoundNBT nbt) {
            nbt.func_74780_a("nicotine_level", this.nicotine_level);
            nbt.func_74780_a("packtobacco", this.packtobacco);
            nbt.func_74757_a("print", this.print);
            nbt.func_74780_a("light_pipe", this.light_pipe);
            nbt.func_74780_a("shop_select", this.shop_select);
            nbt.func_74778_a("select_product", this.select_product);
            nbt.func_74780_a("Smokeless", this.Smokeless);
            nbt.func_74780_a("tick", this.tick);
            nbt.func_74780_a("sec", this.sec);
            nbt.func_74780_a("rand_chew_time", this.rand_chew_time);
            nbt.func_74780_a("rand_chew_time_pick", this.rand_chew_time_pick);
            return nbt;
        }
        
        public void syncData(final World world) {
            this.func_76185_a();
            if (world.field_72995_K) {
                SmokingmodMod.PACKET_HANDLER.sendToServer((Object)new WorldSavedDataSyncMessage(0, this));
            }
            else {
                SmokingmodMod.PACKET_HANDLER.send(PacketDistributor.ALL.noArg(), (Object)new WorldSavedDataSyncMessage(0, this));
            }
        }
        
        public static MapVariables get(final World world) {
            if (world instanceof ServerWorld) {
                return (MapVariables)world.func_73046_m().func_71218_a(DimensionType.field_223227_a_).func_217481_x().func_215752_a((Supplier)MapVariables::new, "smokingmod_mapvars");
            }
            return MapVariables.clientSide;
        }
        
        static {
            MapVariables.clientSide = new MapVariables();
        }
    }
    
    public static class WorldSavedDataSyncMessage
    {
        public int type;
        public WorldSavedData data;
        
        public WorldSavedDataSyncMessage(final PacketBuffer buffer) {
            this.type = buffer.readInt();
            if (this.type == 0) {
                this.data = new MapVariables();
            }
            else {
                this.data = new WorldVariables();
            }
            this.data.func_76184_a(buffer.func_150793_b());
        }
        
        public WorldSavedDataSyncMessage(final int type, final WorldSavedData data) {
            this.type = type;
            this.data = data;
        }
        
        public static void buffer(final WorldSavedDataSyncMessage message, final PacketBuffer buffer) {
            buffer.writeInt(message.type);
            buffer.func_150786_a(message.data.func_189551_b(new CompoundNBT()));
        }
        
        public static void handler(final WorldSavedDataSyncMessage message, final Supplier<NetworkEvent.Context> contextSupplier) {
            final NetworkEvent.Context context = contextSupplier.get();
            final NetworkEvent.Context context2;
            context.enqueueWork(() -> {
                if (context2.getDirection().getReceptionSide().isServer()) {
                    syncData(message, context2.getDirection().getReceptionSide(), context2.getSender().field_70170_p);
                }
                else {
                    syncData(message, context2.getDirection().getReceptionSide(), Minecraft.func_71410_x().field_71439_g.field_70170_p);
                }
                return;
            });
            context.setPacketHandled(true);
        }
        
        private static void syncData(final WorldSavedDataSyncMessage message, final LogicalSide side, final World world) {
            if (side.isServer()) {
                message.data.func_76185_a();
                if (message.type == 0) {
                    SmokingmodMod.PACKET_HANDLER.send(PacketDistributor.ALL.noArg(), (Object)message);
                    world.func_73046_m().func_71218_a(DimensionType.field_223227_a_).func_217481_x().func_215757_a(message.data);
                }
                else {
                    SmokingmodMod.PACKET_HANDLER.send(PacketDistributor.DIMENSION.with((Supplier)world.field_73011_w::func_186058_p), (Object)message);
                    ((ServerWorld)world).func_217481_x().func_215757_a(message.data);
                }
            }
            else if (message.type == 0) {
                MapVariables.clientSide = (MapVariables)message.data;
            }
            else {
                WorldVariables.clientSide = (WorldVariables)message.data;
            }
        }
    }
}
