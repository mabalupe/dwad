// 
// Decompiled by Procyon v0.5.36
// 

package net.mcreator.tobaccoproducts.procedures;

import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.StringTextComponent;
import net.minecraftforge.fml.server.ServerLifecycleHooks;
import net.mcreator.tobaccoproducts.SmokingmodModVariables;
import net.minecraft.world.World;
import java.util.HashMap;
import net.mcreator.tobaccoproducts.SmokingmodModElements.ModElement;
import net.mcreator.tobaccoproducts.SmokingmodModElements;

@Tag
public class CigaretteClickProcProcedure extends SmokingmodModElements.ModElement
{
    public CigaretteClickProcProcedure(final SmokingmodModElements instance) {
        super(instance, 171);
    }
    
    public static void executeProcedure(final HashMap<String, Object> dependencies) {
        if (dependencies.get("world") == null) {
            System.err.println("Failed to load dependency world for procedure CigaretteClickProc!");
            return;
        }
        final World world = dependencies.get("world");
        if (SmokingmodModVariables.MapVariables.get(world).Smokeless > 0.0) {
            SmokingmodModVariables.MapVariables.get(world).Smokeless = 0.0;
            SmokingmodModVariables.MapVariables.get(world).syncData(world);
            SmokingmodModVariables.MapVariables.get(world).tick = 0.0;
            SmokingmodModVariables.MapVariables.get(world).syncData(world);
            SmokingmodModVariables.MapVariables.get(world).sec = 0.0;
            SmokingmodModVariables.MapVariables.get(world).syncData(world);
            SmokingmodModVariables.MapVariables.get(world).rand_chew_time = 0.0;
            SmokingmodModVariables.MapVariables.get(world).syncData(world);
            SmokingmodModVariables.MapVariables.get(world).rand_chew_time_pick = 0.0;
            SmokingmodModVariables.MapVariables.get(world).syncData(world);
            if (world.field_72995_K) {
                final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                if (mcserv != null) {
                    mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You take out your chew."));
                }
            }
        }
        else if (SmokingmodModVariables.WorldVariables.get(world).click == 0.0) {
            SmokingmodModVariables.WorldVariables.get(world).click = 1.0;
            SmokingmodModVariables.WorldVariables.get(world).syncData(world);
            if (world.field_72995_K) {
                final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                if (mcserv != null) {
                    mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("*click*"));
                }
            }
        }
    }
}
