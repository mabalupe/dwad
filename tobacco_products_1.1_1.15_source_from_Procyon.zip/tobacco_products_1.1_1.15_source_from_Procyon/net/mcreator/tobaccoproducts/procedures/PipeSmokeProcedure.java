// 
// Decompiled by Procyon v0.5.36
// 

package net.mcreator.tobaccoproducts.procedures;

import net.minecraft.server.MinecraftServer;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraftforge.fml.server.ServerLifecycleHooks;
import net.minecraft.command.CommandSource;
import net.minecraft.world.server.ServerWorld;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import net.minecraft.command.ICommandSource;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.StringTextComponent;
import net.mcreator.tobaccoproducts.SmokingmodModVariables;
import net.minecraft.world.World;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.Entity;
import java.util.HashMap;
import net.mcreator.tobaccoproducts.SmokingmodModElements.ModElement;
import net.mcreator.tobaccoproducts.SmokingmodModElements;

@Tag
public class PipeSmokeProcedure extends SmokingmodModElements.ModElement
{
    public PipeSmokeProcedure(final SmokingmodModElements instance) {
        super(instance, 106);
    }
    
    public static void executeProcedure(final HashMap<String, Object> dependencies) {
        if (dependencies.get("entity") == null) {
            System.err.println("Failed to load dependency entity for procedure PipeSmoke!");
            return;
        }
        if (dependencies.get("x") == null) {
            System.err.println("Failed to load dependency x for procedure PipeSmoke!");
            return;
        }
        if (dependencies.get("y") == null) {
            System.err.println("Failed to load dependency y for procedure PipeSmoke!");
            return;
        }
        if (dependencies.get("z") == null) {
            System.err.println("Failed to load dependency z for procedure PipeSmoke!");
            return;
        }
        if (dependencies.get("itemstack") == null) {
            System.err.println("Failed to load dependency itemstack for procedure PipeSmoke!");
            return;
        }
        if (dependencies.get("world") == null) {
            System.err.println("Failed to load dependency world for procedure PipeSmoke!");
            return;
        }
        final Entity entity = dependencies.get("entity");
        final int x = dependencies.get("x");
        final int y = dependencies.get("y");
        final int z = dependencies.get("z");
        final ItemStack itemstack = dependencies.get("itemstack");
        final World world = dependencies.get("world");
        double Y = 0.0;
        double tob = 0.0;
        double flav = 0.0;
        double rand = 0.0;
        if (!world.field_72995_K) {
            tob = 0.0;
            if (SmokingmodModVariables.MapVariables.get(world).packtobacco > 0.0) {
                if (itemstack.func_196082_o().func_74769_h("13") <= 0.0) {
                    itemstack.func_196082_o().func_74780_a("13", SmokingmodModVariables.MapVariables.get(world).packtobacco);
                    itemstack.func_200302_a((ITextComponent)new StringTextComponent("Pipe (1/3)"));
                    if (!world.field_72995_K && world.func_73046_m() != null) {
                        world.func_73046_m().func_195571_aL().func_197059_a(new CommandSource(ICommandSource.field_213139_a_, new Vec3d((double)x, (double)y, (double)z), Vec2f.field_189974_a, (ServerWorld)world, 4, "", (ITextComponent)new StringTextComponent(""), world.func_73046_m(), (Entity)null).func_197031_a(), "/kill @e[type=smokingmod:entitybulletpipe_s]");
                    }
                }
                else if (itemstack.func_196082_o().func_74769_h("23") <= 0.0) {
                    itemstack.func_196082_o().func_74780_a("23", SmokingmodModVariables.MapVariables.get(world).packtobacco);
                    itemstack.func_200302_a((ITextComponent)new StringTextComponent("Pipe (2/3)"));
                    if (!world.field_72995_K && world.func_73046_m() != null) {
                        world.func_73046_m().func_195571_aL().func_197059_a(new CommandSource(ICommandSource.field_213139_a_, new Vec3d((double)x, (double)y, (double)z), Vec2f.field_189974_a, (ServerWorld)world, 4, "", (ITextComponent)new StringTextComponent(""), world.func_73046_m(), (Entity)null).func_197031_a(), "/kill @e[type=smokingmod:entitybulletpipe_s]");
                    }
                }
                else if (itemstack.func_196082_o().func_74769_h("33") <= 0.0) {
                    itemstack.func_196082_o().func_74780_a("33", SmokingmodModVariables.MapVariables.get(world).packtobacco);
                    itemstack.func_200302_a((ITextComponent)new StringTextComponent("Pipe (3/3)"));
                    if (!world.field_72995_K && world.func_73046_m() != null) {
                        world.func_73046_m().func_195571_aL().func_197059_a(new CommandSource(ICommandSource.field_213139_a_, new Vec3d((double)x, (double)y, (double)z), Vec2f.field_189974_a, (ServerWorld)world, 4, "", (ITextComponent)new StringTextComponent(""), world.func_73046_m(), (Entity)null).func_197031_a(), "/kill @e[type=smokingmod:entitybulletpipe_s]");
                    }
                    final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                    if (mcserv != null) {
                        mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("Your pipe is full."));
                    }
                }
                SmokingmodModVariables.MapVariables.get(world).packtobacco = 0.0;
                SmokingmodModVariables.MapVariables.get(world).syncData(world);
            }
            else if (itemstack.func_196082_o().func_74769_h("33") <= 0.0 && itemstack.func_196082_o().func_74769_h("23") <= 0.0 && itemstack.func_196082_o().func_74769_h("13") <= 0.0 && !world.field_72995_K && world.func_73046_m() != null) {
                world.func_73046_m().func_195571_aL().func_197059_a(new CommandSource(ICommandSource.field_213139_a_, new Vec3d((double)x, (double)y, (double)z), Vec2f.field_189974_a, (ServerWorld)world, 4, "", (ITextComponent)new StringTextComponent(""), world.func_73046_m(), (Entity)null).func_197031_a(), "/kill @e[type=smokingmod:entitybulletpipe_s]");
            }
            if (itemstack.func_196082_o().func_74769_h("33") > 0.0) {
                tob = itemstack.func_196082_o().func_74769_h("33");
                itemstack.func_196082_o().func_74780_a("33puffs", itemstack.func_196082_o().func_74769_h("33puffs") + 1.0);
                if (itemstack.func_196082_o().func_74769_h("33puffs") >= 15.0) {
                    itemstack.func_196082_o().func_74780_a("33", 0.0);
                    itemstack.func_196082_o().func_74780_a("33puffs", 0.0);
                    itemstack.func_200302_a((ITextComponent)new StringTextComponent("Pipe (2/3)"));
                }
            }
            else if (itemstack.func_196082_o().func_74769_h("23") > 0.0) {
                tob = itemstack.func_196082_o().func_74769_h("23");
                itemstack.func_196082_o().func_74780_a("23puffs", itemstack.func_196082_o().func_74769_h("23puffs") + 1.0);
                if (itemstack.func_196082_o().func_74769_h("23puffs") >= 15.0) {
                    itemstack.func_196082_o().func_74780_a("23", 0.0);
                    itemstack.func_196082_o().func_74780_a("23puffs", 0.0);
                    itemstack.func_200302_a((ITextComponent)new StringTextComponent("Pipe (1/3)"));
                }
            }
            else if (itemstack.func_196082_o().func_74769_h("13") > 0.0) {
                tob = itemstack.func_196082_o().func_74769_h("13");
                itemstack.func_196082_o().func_74780_a("13puffs", itemstack.func_196082_o().func_74769_h("13puffs") + 1.0);
                if (itemstack.func_196082_o().func_74769_h("13puffs") >= 15.0) {
                    itemstack.func_196082_o().func_74780_a("13", 0.0);
                    itemstack.func_196082_o().func_74780_a("13puffs", 0.0);
                    itemstack.func_200302_a((ITextComponent)new StringTextComponent("Pipe (empty)"));
                }
            }
            if (tob > 0.0) {
                if (entity instanceof PlayerEntity) {
                    ((PlayerEntity)entity).func_184811_cZ().func_185145_a(itemstack.func_77973_b(), 70);
                }
                Y = entity.func_226278_cu_() + 1.1;
                if (Math.random() < 0.3) {
                    flav = Math.random();
                    rand = Math.random();
                    if (tob == 1.0) {
                        if (rand <= 0.05 && entity instanceof LivingEntity) {
                            ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76428_l, 120, 0, false, false));
                        }
                        if (rand > 0.05 && rand <= 0.2 && entity instanceof LivingEntity) {
                            ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_188425_z, 1200, 0, false, false));
                        }
                        if (rand > 0.2 && rand < 0.21 && entity instanceof LivingEntity) {
                            ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76421_d, 1200, 0, false, false));
                        }
                        if (flav > 0.0 && flav <= 0.2) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste sweet vanilla notes."));
                            }
                        }
                        if (flav > 0.2 && flav <= 0.5) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste mild chocolate notes."));
                            }
                        }
                        if (flav > 0.5 && flav <= 0.6) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste cocoa."));
                            }
                        }
                        if (flav > 0.6 && flav <= 0.8) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste sweetness."));
                            }
                        }
                        if (flav > 0.8 && flav <= 1.0) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can smell cake."));
                            }
                        }
                    }
                    if (tob == 2.0) {
                        if (rand <= 0.05 && entity instanceof LivingEntity) {
                            ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76428_l, 60, 0, true, false));
                        }
                        if (rand > 0.05 && rand <= 0.1 && entity instanceof LivingEntity) {
                            ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76420_g, 600, 0, true, false));
                        }
                        if (rand > 0.1 && rand < 0.2 && entity instanceof LivingEntity) {
                            ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76429_m, 2400, 0, true, false));
                        }
                        if (flav > 0.0 && flav <= 0.3) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can smell campfire smoke."));
                            }
                        }
                        if (flav > 0.3 && flav <= 0.45) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can smell oak wood."));
                            }
                        }
                        if (flav > 0.45 && flav <= 0.6) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste smoked meat."));
                            }
                        }
                        if (flav > 0.6 && flav <= 0.7) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can smell hickory wood. "));
                            }
                        }
                        if (flav > 0.8 && flav <= 0.9) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste dark tobacco."));
                            }
                        }
                        if (flav > 0.9 && flav <= 1.0) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste earth notes."));
                            }
                        }
                    }
                    if (tob == 3.0) {
                        if (rand <= 0.05 && entity instanceof LivingEntity) {
                            ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76428_l, 60, 0, true, false));
                        }
                        if (rand > 0.05 && rand <= 0.15 && entity instanceof LivingEntity) {
                            ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76422_e, 1200, 0, true, false));
                        }
                        if (rand > 0.15 && rand <= 0.25 && entity instanceof LivingEntity) {
                            ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76420_g, 1200, 0, true, false));
                        }
                        if (flav > 0.0 && flav <= 0.3) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste fruit notes."));
                            }
                        }
                        if (flav > 0.3 && flav <= 0.45) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste hay and oats notes."));
                            }
                        }
                        if (flav > 0.45 && flav <= 0.6) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste tangy citrus notes."));
                            }
                        }
                        if (flav > 0.6 && flav <= 0.7) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can smell flowers. "));
                            }
                        }
                        if (flav > 0.8 && flav <= 0.9) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste woody Virginia."));
                            }
                        }
                        if (flav > 0.9 && flav <= 1.0) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste rum notes."));
                            }
                        }
                    }
                    if (tob == 4.0) {
                        if (rand <= 0.05 && entity instanceof LivingEntity) {
                            ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76428_l, 40, 0, true, false));
                        }
                        if (rand > 0.05 && rand <= 0.15 && entity instanceof LivingEntity) {
                            ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76422_e, 1200, 0, true, false));
                        }
                        if (rand > 0.15 && rand <= 0.25 && entity instanceof LivingEntity) {
                            ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76424_c, 1200, 0, true, false));
                        }
                        if (flav > 0.0 && flav <= 0.3) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste fruit notes."));
                            }
                        }
                        if (flav > 0.3 && flav <= 0.45) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste hay notes."));
                            }
                        }
                        if (flav > 0.45 && flav <= 0.6) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can smell wood logs."));
                            }
                        }
                        if (flav > 0.6 && flav <= 0.7) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste sweet tobacco."));
                            }
                        }
                        if (flav > 0.8 && flav <= 0.9) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste sweet Virginia."));
                            }
                        }
                        if (flav > 0.9 && flav <= 1.0) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste raisins notes."));
                            }
                        }
                    }
                    if (tob == 5.0) {
                        if (rand <= 0.05 && entity instanceof LivingEntity) {
                            ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76428_l, 40, 0, true, false));
                        }
                        if (rand > 0.05 && rand <= 0.15 && entity instanceof LivingEntity) {
                            ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76422_e, 1200, 0, true, false));
                        }
                        if (rand > 0.15 && rand <= 0.25 && entity instanceof LivingEntity) {
                            ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76424_c, 1200, 0, true, false));
                        }
                        if (flav > 0.0 && flav <= 0.3) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste fruit notes."));
                            }
                        }
                        if (flav > 0.3 && flav <= 0.45) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste hay notes."));
                            }
                        }
                        if (flav > 0.45 && flav <= 0.6) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can smell wood logs."));
                            }
                        }
                        if (flav > 0.6 && flav <= 0.7) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste sweet tobacco."));
                            }
                        }
                        if (flav > 0.8 && flav <= 0.9) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste nuts notes."));
                            }
                        }
                        if (flav > 0.9 && flav <= 1.0) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste cedar notes."));
                            }
                        }
                    }
                    if (tob == 6.0) {
                        if (rand <= 0.05 && entity instanceof LivingEntity) {
                            ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76428_l, 40, 0, true, false));
                        }
                        if (rand > 0.05 && rand <= 0.15 && entity instanceof LivingEntity) {
                            ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76422_e, 1200, 0, true, false));
                        }
                        if (rand > 0.15 && rand <= 0.25 && entity instanceof LivingEntity) {
                            ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76420_g, 1200, 0, true, false));
                        }
                        if (flav > 0.0 && flav <= 0.3) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can smell smoked meat."));
                            }
                        }
                        if (flav > 0.3 && flav <= 0.45) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste heavy smoke."));
                            }
                        }
                        if (flav > 0.45 && flav <= 0.6) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can smell fireplace aroma."));
                            }
                        }
                        if (flav > 0.6 && flav <= 0.7) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste dark tobacco."));
                            }
                        }
                        if (flav > 0.8 && flav <= 0.9) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste nuts notes."));
                            }
                        }
                        if (flav > 0.9 && flav <= 1.0) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste wooden notes."));
                            }
                        }
                    }
                    if (tob == 7.0) {
                        if (rand <= 0.05 && entity instanceof LivingEntity) {
                            ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76428_l, 40, 0, true, false));
                        }
                        if (rand > 0.05 && rand <= 0.15 && entity instanceof LivingEntity) {
                            ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76422_e, 1200, 0, true, false));
                        }
                        if (rand > 0.15 && rand <= 0.25 && entity instanceof LivingEntity) {
                            ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76424_c, 1200, 0, true, false));
                        }
                        if (flav > 0.0 && flav <= 0.3) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can smell barn aroma."));
                            }
                        }
                        if (flav > 0.3 && flav <= 0.45) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste pleasant smoke."));
                            }
                        }
                        if (flav > 0.45 && flav <= 0.6) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste fruity notes."));
                            }
                        }
                        if (flav > 0.6 && flav <= 0.7) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste nuts notes."));
                            }
                        }
                        if (flav > 0.8 && flav <= 0.9) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste citrus notes."));
                            }
                        }
                        if (flav > 0.9 && flav <= 1.0) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste cedar notes."));
                            }
                        }
                    }
                    if (tob == 8.0) {
                        if (rand <= 0.05 && entity instanceof LivingEntity) {
                            ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_188425_z, 800, 0, true, false));
                        }
                        if (rand > 0.05 && rand <= 0.15 && entity instanceof LivingEntity) {
                            ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76422_e, 1200, 0, true, false));
                        }
                        if (rand > 0.15 && rand <= 0.25 && entity instanceof LivingEntity) {
                            ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76420_g, 1200, 0, true, false));
                        }
                        if (flav > 0.0 && flav <= 0.3) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can smell barn aroma."));
                            }
                        }
                        if (flav > 0.3 && flav <= 0.45) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can smell smoked meat aroma."));
                            }
                        }
                        if (flav > 0.45 && flav <= 0.6) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste citrus notes."));
                            }
                        }
                        if (flav > 0.6 && flav <= 0.7) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste nuts notes."));
                            }
                        }
                        if (flav > 0.8 && flav <= 0.9) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste dark wood notes."));
                            }
                        }
                        if (flav > 0.9 && flav <= 1.0) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste light flower notes."));
                            }
                        }
                    }
                    if (tob == 9.0) {
                        if (rand <= 0.05 && entity instanceof LivingEntity) {
                            ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_188425_z, 800, 0, true, false));
                        }
                        if (rand > 0.05 && rand <= 0.15 && entity instanceof LivingEntity) {
                            ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76428_l, 160, 0, true, false));
                        }
                        if (rand > 0.15 && rand <= 0.25 && entity instanceof LivingEntity) {
                            ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76427_o, 1200, 0, true, false));
                        }
                        if (flav > 0.0 && flav <= 0.3) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You taste leather notes."));
                            }
                        }
                        if (flav > 0.3 && flav <= 0.45) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste salty earth."));
                            }
                        }
                        if (flav > 0.45 && flav <= 0.6) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste red fruits notes."));
                            }
                        }
                        if (flav > 0.6 && flav <= 0.7) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste subtle sweetness."));
                            }
                        }
                        if (flav > 0.8 && flav <= 1.0) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can slightly taste spices."));
                            }
                        }
                    }
                    if (tob == 10.0) {
                        if (rand <= 0.05 && entity instanceof LivingEntity) {
                            ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76422_e, 800, 0, true, false));
                        }
                        if (rand > 0.05 && rand <= 0.15 && entity instanceof LivingEntity) {
                            ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76428_l, 160, 0, true, false));
                        }
                        if (rand > 0.15 && rand <= 0.25 && entity instanceof LivingEntity) {
                            ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76429_m, 1200, 0, true, false));
                        }
                        if (flav > 0.0 && flav <= 0.3) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You taste smooth smoke."));
                            }
                        }
                        if (flav > 0.3 && flav <= 0.45) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste earth notes."));
                            }
                        }
                        if (flav > 0.45 && flav <= 0.6) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste fruity Virginia."));
                            }
                        }
                        if (flav > 0.6 && flav <= 0.7) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste sweet Cavendish."));
                            }
                        }
                        if (flav > 0.8 && flav <= 1.0) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can slightly taste caramel."));
                            }
                        }
                    }
                    if (tob == 11.0) {
                        if (rand <= 0.05 && entity instanceof LivingEntity) {
                            ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76422_e, 800, 0, true, false));
                        }
                        if (rand > 0.05 && rand <= 0.15 && entity instanceof LivingEntity) {
                            ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76428_l, 80, 0, true, false));
                        }
                        if (rand > 0.15 && rand <= 0.25 && entity instanceof LivingEntity) {
                            ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_188425_z, 1200, 0, true, false));
                        }
                        if (flav > 0.0 && flav <= 0.3) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You taste smooth smoke."));
                            }
                        }
                        if (flav > 0.3 && flav <= 0.45) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste nutty notes."));
                            }
                        }
                        if (flav > 0.45 && flav <= 0.6) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste tangy cherries."));
                            }
                        }
                        if (flav > 0.6 && flav <= 0.7) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste sweet Virginia."));
                            }
                        }
                        if (flav > 0.8 && flav <= 1.0) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste citrus notes."));
                            }
                        }
                    }
                    if (tob == 12.0) {
                        if (rand <= 0.05 && entity instanceof LivingEntity) {
                            ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_188425_z, 2400, 0, true, false));
                        }
                        if (rand > 0.05 && rand <= 0.15 && entity instanceof LivingEntity) {
                            ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76428_l, 20, 0, true, false));
                        }
                        if (rand > 0.15 && rand <= 0.25 && entity instanceof LivingEntity) {
                            ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76429_m, 1200, 0, true, false));
                        }
                        if (flav > 0.0 && flav <= 0.3) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You taste smooth smoke."));
                            }
                        }
                        if (flav > 0.3 && flav <= 0.45) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste vanilla notes."));
                            }
                        }
                        if (flav > 0.45 && flav <= 0.6) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste honey notes."));
                            }
                        }
                        if (flav > 0.6 && flav <= 0.7) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste sweet Virginia."));
                            }
                        }
                        if (flav > 0.8 && flav <= 1.0) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste citrus notes."));
                            }
                        }
                    }
                }
            }
        }
    }
}
