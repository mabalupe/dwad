// 
// Decompiled by Procyon v0.5.36
// 

package net.mcreator.tobaccoproducts.procedures;

import net.minecraft.block.BlockState;
import net.mcreator.tobaccoproducts.block.TobaccoPlantStage3Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.ItemEntity;
import net.minecraft.util.IItemProvider;
import net.minecraft.item.ItemStack;
import net.mcreator.tobaccoproducts.item.TobaccoSeedItem;
import net.mcreator.tobaccoproducts.block.TobaccoPlantStage2Block;
import net.minecraft.block.Block;
import net.mcreator.tobaccoproducts.block.TobaccoPlanyStage1Block;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.block.Blocks;
import net.mcreator.tobaccoproducts.block.TobaccoPlantStage0Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import java.util.HashMap;
import net.mcreator.tobaccoproducts.SmokingmodModElements.ModElement;
import net.mcreator.tobaccoproducts.SmokingmodModElements;

@Tag
public class TobaccoPlantGrowUpdateProcedure extends SmokingmodModElements.ModElement
{
    public TobaccoPlantGrowUpdateProcedure(final SmokingmodModElements instance) {
        super(instance, 115);
    }
    
    public static void executeProcedure(final HashMap<String, Object> dependencies) {
        if (dependencies.get("x") == null) {
            System.err.println("Failed to load dependency x for procedure TobaccoPlantGrowUpdate!");
            return;
        }
        if (dependencies.get("y") == null) {
            System.err.println("Failed to load dependency y for procedure TobaccoPlantGrowUpdate!");
            return;
        }
        if (dependencies.get("z") == null) {
            System.err.println("Failed to load dependency z for procedure TobaccoPlantGrowUpdate!");
            return;
        }
        if (dependencies.get("world") == null) {
            System.err.println("Failed to load dependency world for procedure TobaccoPlantGrowUpdate!");
            return;
        }
        final int x = dependencies.get("x");
        final int y = dependencies.get("y");
        final int z = dependencies.get("z");
        final World world = dependencies.get("world");
        if (!world.field_72995_K) {
            final BlockPos _bp = new BlockPos(x, y, z);
            final TileEntity _tileEntity = world.func_175625_s(_bp);
            final BlockState _bs = world.func_180495_p(_bp);
            if (_tileEntity != null) {
                _tileEntity.getTileData().func_74780_a("randomUpdateNoFarmland", Math.random());
            }
            world.func_184138_a(_bp, _bs, _bs, 3);
        }
        if (!world.field_72995_K) {
            final BlockPos _bp = new BlockPos(x, y, z);
            final TileEntity _tileEntity = world.func_175625_s(_bp);
            final BlockState _bs = world.func_180495_p(_bp);
            if (_tileEntity != null) {
                _tileEntity.getTileData().func_74780_a("randomUpdateGrow", Math.random());
            }
            world.func_184138_a(_bp, _bs, _bs, 3);
        }
        if (world.func_180495_p(new BlockPos(x, y, z)).func_177230_c() == TobaccoPlantStage0Block.block.func_176223_P().func_177230_c()) {
            if (Blocks.field_150458_ak.func_176223_P().func_177230_c() == world.func_180495_p(new BlockPos(x, y - 1, z)).func_177230_c()) {
                if (world.func_72935_r()) {
                    if (world.func_201696_r(new BlockPos(x, y, z)) >= 10 && new Object() {
                        public double getValue(final BlockPos pos, final String tag) {
                            final TileEntity tileEntity = world.func_175625_s(pos);
                            if (tileEntity != null) {
                                return tileEntity.getTileData().func_74769_h(tag);
                            }
                            return -1.0;
                        }
                    }.getValue(new BlockPos(x, y, z), "randomUpdateGrow") <= 0.005) {
                        world.func_180501_a(new BlockPos(x, y, z), Blocks.field_150350_a.func_176223_P(), 3);
                        world.func_180501_a(new BlockPos(x, y, z), TobaccoPlanyStage1Block.block.func_176223_P(), 3);
                    }
                }
                else if (!world.func_72935_r() && world.func_201696_r(new BlockPos(x, y, z)) >= 10 && new Object() {
                    public double getValue(final BlockPos pos, final String tag) {
                        final TileEntity tileEntity = world.func_175625_s(pos);
                        if (tileEntity != null) {
                            return tileEntity.getTileData().func_74769_h(tag);
                        }
                        return -1.0;
                    }
                }.getValue(new BlockPos(x, y, z), "randomUpdateGrow") <= 0.005) {
                    world.func_180501_a(new BlockPos(x, y, z), Blocks.field_150350_a.func_176223_P(), 3);
                    world.func_180501_a(new BlockPos(x, y, z), TobaccoPlanyStage1Block.block.func_176223_P(), 3);
                }
            }
            else if (Blocks.field_150458_ak.func_176223_P().func_177230_c() != world.func_180495_p(new BlockPos(x, y - 1, z)).func_177230_c()) {
                Block.func_220075_c(world.func_180495_p(new BlockPos(x, y, z)), world, new BlockPos(x, y, z));
                world.func_175655_b(new BlockPos(x, y, z), false);
            }
        }
        else if (world.func_180495_p(new BlockPos(x, y, z)).func_177230_c() == TobaccoPlanyStage1Block.block.func_176223_P().func_177230_c()) {
            if (Blocks.field_150458_ak.func_176223_P().func_177230_c() == world.func_180495_p(new BlockPos(x, y - 1, z)).func_177230_c()) {
                if (world.func_72935_r()) {
                    if (world.func_201696_r(new BlockPos(x, y, z)) >= 10 && new Object() {
                        public double getValue(final BlockPos pos, final String tag) {
                            final TileEntity tileEntity = world.func_175625_s(pos);
                            if (tileEntity != null) {
                                return tileEntity.getTileData().func_74769_h(tag);
                            }
                            return -1.0;
                        }
                    }.getValue(new BlockPos(x, y, z), "randomUpdateGrow") <= 0.005) {
                        world.func_180501_a(new BlockPos(x, y, z), Blocks.field_150350_a.func_176223_P(), 3);
                        world.func_180501_a(new BlockPos(x, y, z), TobaccoPlantStage2Block.block.func_176223_P(), 3);
                    }
                }
                else if (!world.func_72935_r() && world.func_201696_r(new BlockPos(x, y, z)) >= 10 && new Object() {
                    public double getValue(final BlockPos pos, final String tag) {
                        final TileEntity tileEntity = world.func_175625_s(pos);
                        if (tileEntity != null) {
                            return tileEntity.getTileData().func_74769_h(tag);
                        }
                        return -1.0;
                    }
                }.getValue(new BlockPos(x, y, z), "randomUpdateGrow") <= 0.005) {
                    world.func_180501_a(new BlockPos(x, y, z), Blocks.field_150350_a.func_176223_P(), 3);
                    world.func_180501_a(new BlockPos(x, y, z), TobaccoPlantStage2Block.block.func_176223_P(), 3);
                }
            }
            else if (Blocks.field_150458_ak.func_176223_P().func_177230_c() != world.func_180495_p(new BlockPos(x, y - 1, z)).func_177230_c()) {
                if (new Object() {
                    public double getValue(final BlockPos pos, final String tag) {
                        final TileEntity tileEntity = world.func_175625_s(pos);
                        if (tileEntity != null) {
                            return tileEntity.getTileData().func_74769_h(tag);
                        }
                        return -1.0;
                    }
                }.getValue(new BlockPos(x, y, z), "randomUpdateNoFarmland") <= 0.25) {
                    if (!world.field_72995_K) {
                        final ItemEntity entityToSpawn = new ItemEntity(world, (double)x, (double)y, (double)z, new ItemStack((IItemProvider)TobaccoSeedItem.block, 1));
                        entityToSpawn.func_174867_a(10);
                        world.func_217376_c((Entity)entityToSpawn);
                    }
                    if (!world.field_72995_K) {
                        final ItemEntity entityToSpawn = new ItemEntity(world, (double)x, (double)y, (double)z, new ItemStack((IItemProvider)TobaccoSeedItem.block, 1));
                        entityToSpawn.func_174867_a(10);
                        world.func_217376_c((Entity)entityToSpawn);
                    }
                    if (!world.field_72995_K) {
                        final ItemEntity entityToSpawn = new ItemEntity(world, (double)x, (double)y, (double)z, new ItemStack((IItemProvider)TobaccoSeedItem.block, 1));
                        entityToSpawn.func_174867_a(10);
                        world.func_217376_c((Entity)entityToSpawn);
                    }
                    Block.func_220075_c(world.func_180495_p(new BlockPos(x, y, z)), world, new BlockPos(x, y, z));
                    world.func_175655_b(new BlockPos(x, y, z), false);
                }
                else if (new Object() {
                    public double getValue(final BlockPos pos, final String tag) {
                        final TileEntity tileEntity = world.func_175625_s(pos);
                        if (tileEntity != null) {
                            return tileEntity.getTileData().func_74769_h(tag);
                        }
                        return -1.0;
                    }
                }.getValue(new BlockPos(x, y, z), "randomUpdateNoFarmland") > 0.25) {
                    if (!world.field_72995_K) {
                        final ItemEntity entityToSpawn = new ItemEntity(world, (double)x, (double)y, (double)z, new ItemStack((IItemProvider)TobaccoSeedItem.block, 1));
                        entityToSpawn.func_174867_a(10);
                        world.func_217376_c((Entity)entityToSpawn);
                    }
                    if (!world.field_72995_K) {
                        final ItemEntity entityToSpawn = new ItemEntity(world, (double)x, (double)y, (double)z, new ItemStack((IItemProvider)TobaccoSeedItem.block, 1));
                        entityToSpawn.func_174867_a(10);
                        world.func_217376_c((Entity)entityToSpawn);
                    }
                    Block.func_220075_c(world.func_180495_p(new BlockPos(x, y, z)), world, new BlockPos(x, y, z));
                    world.func_175655_b(new BlockPos(x, y, z), false);
                }
            }
        }
        else if (world.func_180495_p(new BlockPos(x, y, z)).func_177230_c() == TobaccoPlantStage2Block.block.func_176223_P().func_177230_c()) {
            if (Blocks.field_150458_ak.func_176223_P().func_177230_c() == world.func_180495_p(new BlockPos(x, y - 1, z)).func_177230_c()) {
                if (world.func_72935_r()) {
                    if (world.func_201696_r(new BlockPos(x, y, z)) >= 10 && new Object() {
                        public double getValue(final BlockPos pos, final String tag) {
                            final TileEntity tileEntity = world.func_175625_s(pos);
                            if (tileEntity != null) {
                                return tileEntity.getTileData().func_74769_h(tag);
                            }
                            return -1.0;
                        }
                    }.getValue(new BlockPos(x, y, z), "randomUpdateGrow") <= 0.005) {
                        world.func_180501_a(new BlockPos(x, y, z), Blocks.field_150350_a.func_176223_P(), 3);
                        world.func_180501_a(new BlockPos(x, y, z), TobaccoPlantStage3Block.block.func_176223_P(), 3);
                    }
                }
                else if (!world.func_72935_r() && world.func_201696_r(new BlockPos(x, y, z)) >= 10 && new Object() {
                    public double getValue(final BlockPos pos, final String tag) {
                        final TileEntity tileEntity = world.func_175625_s(pos);
                        if (tileEntity != null) {
                            return tileEntity.getTileData().func_74769_h(tag);
                        }
                        return -1.0;
                    }
                }.getValue(new BlockPos(x, y, z), "randomUpdateGrow") <= 0.005) {
                    world.func_180501_a(new BlockPos(x, y, z), Blocks.field_150350_a.func_176223_P(), 3);
                    world.func_180501_a(new BlockPos(x, y, z), TobaccoPlantStage3Block.block.func_176223_P(), 3);
                }
            }
            else if (Blocks.field_150458_ak.func_176223_P().func_177230_c() != world.func_180495_p(new BlockPos(x, y - 1, z)).func_177230_c()) {
                if (new Object() {
                    public double getValue(final BlockPos pos, final String tag) {
                        final TileEntity tileEntity = world.func_175625_s(pos);
                        if (tileEntity != null) {
                            return tileEntity.getTileData().func_74769_h(tag);
                        }
                        return -1.0;
                    }
                }.getValue(new BlockPos(x, y, z), "randomUpdateNoFarmland") <= 0.5) {
                    if (new Object() {
                        public double getValue(final BlockPos pos, final String tag) {
                            final TileEntity tileEntity = world.func_175625_s(pos);
                            if (tileEntity != null) {
                                return tileEntity.getTileData().func_74769_h(tag);
                            }
                            return -1.0;
                        }
                    }.getValue(new BlockPos(x, y, z), "randomUpdateNoFarmland") <= 0.25) {
                        if (!world.field_72995_K) {
                            final ItemEntity entityToSpawn = new ItemEntity(world, (double)x, (double)y, (double)z, new ItemStack((IItemProvider)TobaccoSeedItem.block, 1));
                            entityToSpawn.func_174867_a(10);
                            world.func_217376_c((Entity)entityToSpawn);
                        }
                        if (!world.field_72995_K) {
                            final ItemEntity entityToSpawn = new ItemEntity(world, (double)x, (double)y, (double)z, new ItemStack((IItemProvider)TobaccoSeedItem.block, 1));
                            entityToSpawn.func_174867_a(10);
                            world.func_217376_c((Entity)entityToSpawn);
                        }
                        if (!world.field_72995_K) {
                            final ItemEntity entityToSpawn = new ItemEntity(world, (double)x, (double)y, (double)z, new ItemStack((IItemProvider)TobaccoSeedItem.block, 1));
                            entityToSpawn.func_174867_a(10);
                            world.func_217376_c((Entity)entityToSpawn);
                        }
                        Block.func_220075_c(world.func_180495_p(new BlockPos(x, y, z)), world, new BlockPos(x, y, z));
                        world.func_175655_b(new BlockPos(x, y, z), false);
                    }
                    else if (new Object() {
                        public double getValue(final BlockPos pos, final String tag) {
                            final TileEntity tileEntity = world.func_175625_s(pos);
                            if (tileEntity != null) {
                                return tileEntity.getTileData().func_74769_h(tag);
                            }
                            return -1.0;
                        }
                    }.getValue(new BlockPos(x, y, z), "randomUpdateNoFarmland") > 0.25) {
                        if (!world.field_72995_K) {
                            final ItemEntity entityToSpawn = new ItemEntity(world, (double)x, (double)y, (double)z, new ItemStack((IItemProvider)TobaccoSeedItem.block, 1));
                            entityToSpawn.func_174867_a(10);
                            world.func_217376_c((Entity)entityToSpawn);
                        }
                        if (!world.field_72995_K) {
                            final ItemEntity entityToSpawn = new ItemEntity(world, (double)x, (double)y, (double)z, new ItemStack((IItemProvider)TobaccoSeedItem.block, 1));
                            entityToSpawn.func_174867_a(10);
                            world.func_217376_c((Entity)entityToSpawn);
                        }
                        Block.func_220075_c(world.func_180495_p(new BlockPos(x, y, z)), world, new BlockPos(x, y, z));
                        world.func_175655_b(new BlockPos(x, y, z), false);
                    }
                }
                else if (new Object() {
                    public double getValue(final BlockPos pos, final String tag) {
                        final TileEntity tileEntity = world.func_175625_s(pos);
                        if (tileEntity != null) {
                            return tileEntity.getTileData().func_74769_h(tag);
                        }
                        return -1.0;
                    }
                }.getValue(new BlockPos(x, y, z), "randomUpdateNoFarmland") > 0.5) {
                    if (new Object() {
                        public double getValue(final BlockPos pos, final String tag) {
                            final TileEntity tileEntity = world.func_175625_s(pos);
                            if (tileEntity != null) {
                                return tileEntity.getTileData().func_74769_h(tag);
                            }
                            return -1.0;
                        }
                    }.getValue(new BlockPos(x, y, z), "randomUpdateNoFarmland") <= 0.75) {
                        if (!world.field_72995_K) {
                            final ItemEntity entityToSpawn = new ItemEntity(world, (double)x, (double)y, (double)z, new ItemStack((IItemProvider)TobaccoSeedItem.block, 1));
                            entityToSpawn.func_174867_a(10);
                            world.func_217376_c((Entity)entityToSpawn);
                        }
                        Block.func_220075_c(world.func_180495_p(new BlockPos(x, y, z)), world, new BlockPos(x, y, z));
                        world.func_175655_b(new BlockPos(x, y, z), false);
                    }
                    else if (new Object() {
                        public double getValue(final BlockPos pos, final String tag) {
                            final TileEntity tileEntity = world.func_175625_s(pos);
                            if (tileEntity != null) {
                                return tileEntity.getTileData().func_74769_h(tag);
                            }
                            return -1.0;
                        }
                    }.getValue(new BlockPos(x, y, z), "randomUpdateNoFarmland") > 0.75) {
                        Block.func_220075_c(world.func_180495_p(new BlockPos(x, y, z)), world, new BlockPos(x, y, z));
                        world.func_175655_b(new BlockPos(x, y, z), false);
                    }
                }
            }
        }
        else if (world.func_180495_p(new BlockPos(x, y, z)).func_177230_c() == TobaccoPlantStage3Block.block.func_176223_P().func_177230_c() && Blocks.field_150458_ak.func_176223_P().func_177230_c() != world.func_180495_p(new BlockPos(x, y - 1, z)).func_177230_c()) {
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "randomUpdateNoFarmland") <= 0.5) {
                if (new Object() {
                    public double getValue(final BlockPos pos, final String tag) {
                        final TileEntity tileEntity = world.func_175625_s(pos);
                        if (tileEntity != null) {
                            return tileEntity.getTileData().func_74769_h(tag);
                        }
                        return -1.0;
                    }
                }.getValue(new BlockPos(x, y, z), "randomUpdateNoFarmland") <= 0.25) {
                    if (!world.field_72995_K) {
                        final ItemEntity entityToSpawn = new ItemEntity(world, (double)x, (double)y, (double)z, new ItemStack((IItemProvider)TobaccoSeedItem.block, 1));
                        entityToSpawn.func_174867_a(10);
                        world.func_217376_c((Entity)entityToSpawn);
                    }
                    if (!world.field_72995_K) {
                        final ItemEntity entityToSpawn = new ItemEntity(world, (double)x, (double)y, (double)z, new ItemStack((IItemProvider)TobaccoSeedItem.block, 1));
                        entityToSpawn.func_174867_a(10);
                        world.func_217376_c((Entity)entityToSpawn);
                    }
                    if (!world.field_72995_K) {
                        final ItemEntity entityToSpawn = new ItemEntity(world, (double)x, (double)y, (double)z, new ItemStack((IItemProvider)TobaccoSeedItem.block, 1));
                        entityToSpawn.func_174867_a(10);
                        world.func_217376_c((Entity)entityToSpawn);
                    }
                    if (!world.field_72995_K) {
                        final ItemEntity entityToSpawn = new ItemEntity(world, (double)x, (double)y, (double)z, new ItemStack((IItemProvider)TobaccoSeedItem.block, 1));
                        entityToSpawn.func_174867_a(10);
                        world.func_217376_c((Entity)entityToSpawn);
                    }
                    Block.func_220075_c(world.func_180495_p(new BlockPos(x, y, z)), world, new BlockPos(x, y, z));
                    world.func_175655_b(new BlockPos(x, y, z), false);
                }
                else if (new Object() {
                    public double getValue(final BlockPos pos, final String tag) {
                        final TileEntity tileEntity = world.func_175625_s(pos);
                        if (tileEntity != null) {
                            return tileEntity.getTileData().func_74769_h(tag);
                        }
                        return -1.0;
                    }
                }.getValue(new BlockPos(x, y, z), "randomUpdateNoFarmland") > 0.25) {
                    if (!world.field_72995_K) {
                        final ItemEntity entityToSpawn = new ItemEntity(world, (double)x, (double)y, (double)z, new ItemStack((IItemProvider)TobaccoSeedItem.block, 1));
                        entityToSpawn.func_174867_a(10);
                        world.func_217376_c((Entity)entityToSpawn);
                    }
                    if (!world.field_72995_K) {
                        final ItemEntity entityToSpawn = new ItemEntity(world, (double)x, (double)y, (double)z, new ItemStack((IItemProvider)TobaccoSeedItem.block, 1));
                        entityToSpawn.func_174867_a(10);
                        world.func_217376_c((Entity)entityToSpawn);
                    }
                    if (!world.field_72995_K) {
                        final ItemEntity entityToSpawn = new ItemEntity(world, (double)x, (double)y, (double)z, new ItemStack((IItemProvider)TobaccoSeedItem.block, 1));
                        entityToSpawn.func_174867_a(10);
                        world.func_217376_c((Entity)entityToSpawn);
                    }
                    Block.func_220075_c(world.func_180495_p(new BlockPos(x, y, z)), world, new BlockPos(x, y, z));
                    world.func_175655_b(new BlockPos(x, y, z), false);
                }
            }
            else if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "randomUpdateNoFarmland") > 0.5) {
                if (new Object() {
                    public double getValue(final BlockPos pos, final String tag) {
                        final TileEntity tileEntity = world.func_175625_s(pos);
                        if (tileEntity != null) {
                            return tileEntity.getTileData().func_74769_h(tag);
                        }
                        return -1.0;
                    }
                }.getValue(new BlockPos(x, y, z), "randomUpdateNoFarmland") <= 0.75) {
                    if (!world.field_72995_K) {
                        final ItemEntity entityToSpawn = new ItemEntity(world, (double)x, (double)y, (double)z, new ItemStack((IItemProvider)TobaccoSeedItem.block, 1));
                        entityToSpawn.func_174867_a(10);
                        world.func_217376_c((Entity)entityToSpawn);
                    }
                    if (!world.field_72995_K) {
                        final ItemEntity entityToSpawn = new ItemEntity(world, (double)x, (double)y, (double)z, new ItemStack((IItemProvider)TobaccoSeedItem.block, 1));
                        entityToSpawn.func_174867_a(10);
                        world.func_217376_c((Entity)entityToSpawn);
                    }
                    Block.func_220075_c(world.func_180495_p(new BlockPos(x, y, z)), world, new BlockPos(x, y, z));
                    world.func_175655_b(new BlockPos(x, y, z), false);
                }
                else if (new Object() {
                    public double getValue(final BlockPos pos, final String tag) {
                        final TileEntity tileEntity = world.func_175625_s(pos);
                        if (tileEntity != null) {
                            return tileEntity.getTileData().func_74769_h(tag);
                        }
                        return -1.0;
                    }
                }.getValue(new BlockPos(x, y, z), "randomUpdateNoFarmland") > 0.75) {
                    if (!world.field_72995_K) {
                        final ItemEntity entityToSpawn = new ItemEntity(world, (double)x, (double)y, (double)z, new ItemStack((IItemProvider)TobaccoSeedItem.block, 1));
                        entityToSpawn.func_174867_a(10);
                        world.func_217376_c((Entity)entityToSpawn);
                    }
                    Block.func_220075_c(world.func_180495_p(new BlockPos(x, y, z)), world, new BlockPos(x, y, z));
                    world.func_175655_b(new BlockPos(x, y, z), false);
                }
            }
        }
    }
}
