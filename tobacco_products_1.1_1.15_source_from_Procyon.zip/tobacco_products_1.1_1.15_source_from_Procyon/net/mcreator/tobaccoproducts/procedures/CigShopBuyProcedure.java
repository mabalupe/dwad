// 
// Decompiled by Procyon v0.5.36
// 

package net.mcreator.tobaccoproducts.procedures;

import net.minecraftforge.items.ItemHandlerHelper;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.IItemProvider;
import net.minecraft.item.Items;
import net.minecraft.inventory.container.Container;
import net.minecraft.inventory.container.Slot;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.Entity;
import java.util.HashMap;
import net.mcreator.tobaccoproducts.SmokingmodModElements.ModElement;
import net.mcreator.tobaccoproducts.SmokingmodModElements;

@Tag
public class CigShopBuyProcedure extends SmokingmodModElements.ModElement
{
    public CigShopBuyProcedure(final SmokingmodModElements instance) {
        super(instance, 125);
    }
    
    public static void executeProcedure(final HashMap<String, Object> dependencies) {
        if (dependencies.get("entity") == null) {
            System.err.println("Failed to load dependency entity for procedure CigShopBuy!");
            return;
        }
        final Entity entity = dependencies.get("entity");
        if (new Object() {
            public ItemStack getItemStack(final int sltid) {
                final Entity _ent = entity;
                if (_ent instanceof ServerPlayerEntity) {
                    final Container _current = ((ServerPlayerEntity)_ent).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            return ((Map)invobj).get(sltid).func_75211_c();
                        }
                    }
                }
                return ItemStack.field_190927_a;
            }
        }.getItemStack(0).func_77973_b() == new ItemStack((IItemProvider)Items.field_151166_bC, 1).func_77973_b()) {
            if (entity instanceof PlayerEntity) {
                final ItemStack _setstack = new Object() {
                    public ItemStack getItemStack(final int sltid) {
                        final Entity _ent = entity;
                        if (_ent instanceof ServerPlayerEntity) {
                            final Container _current = ((ServerPlayerEntity)_ent).field_71070_bA;
                            if (_current instanceof Supplier) {
                                final Object invobj = ((Supplier)_current).get();
                                if (invobj instanceof Map) {
                                    return ((Map)invobj).get(sltid).func_75211_c();
                                }
                            }
                        }
                        return ItemStack.field_190927_a;
                    }
                }.getItemStack(1);
                _setstack.func_190920_e(1);
                ItemHandlerHelper.giveItemToPlayer((PlayerEntity)entity, _setstack);
            }
            final Entity _ent = entity;
            if (_ent instanceof ServerPlayerEntity) {
                final Container _current = ((ServerPlayerEntity)_ent).field_71070_bA;
                if (_current instanceof Supplier) {
                    final Object invobj = ((Supplier)_current).get();
                    if (invobj instanceof Map) {
                        ((Map)invobj).get(0).func_75209_a(1);
                        _current.func_75142_b();
                    }
                }
            }
        }
    }
}
