// 
// Decompiled by Procyon v0.5.36
// 

package net.mcreator.tobaccoproducts.procedures;

import net.minecraft.block.BlockState;
import net.minecraft.inventory.container.Container;
import net.mcreator.tobaccoproducts.item.BurleyLeafItemItem;
import net.mcreator.tobaccoproducts.item.TobaccoLeafItemItem;
import net.mcreator.tobaccoproducts.item.BurleySeedsItem;
import net.mcreator.tobaccoproducts.item.TobaccoSeedItem;
import net.minecraft.block.Blocks;
import net.mcreator.tobaccoproducts.item.TundraSpiritCitrusBerryItem;
import net.mcreator.tobaccoproducts.item.LyntLiquoriceItem;
import net.mcreator.tobaccoproducts.item.LyntMintStrongItem;
import net.mcreator.tobaccoproducts.item.LyntMintItem;
import net.mcreator.tobaccoproducts.item.CarlosBoxItem;
import net.mcreator.tobaccoproducts.item.CarlosItem;
import net.mcreator.tobaccoproducts.item.JoseBoxItem;
import net.mcreator.tobaccoproducts.item.JoseItem;
import net.mcreator.tobaccoproducts.item.LucasBoxItem;
import net.mcreator.tobaccoproducts.item.LucasItem;
import net.mcreator.tobaccoproducts.item.WildWestBoxItem;
import net.mcreator.tobaccoproducts.item.WildWestItem;
import net.mcreator.tobaccoproducts.item.RomeoJulietCoronaBoxItem;
import net.mcreator.tobaccoproducts.item.RomeoJulietCoronaItem;
import net.mcreator.tobaccoproducts.item.PioneerRoadItem;
import net.mcreator.tobaccoproducts.item.NarrowWellItem;
import net.mcreator.tobaccoproducts.item.FirstEncounterItem;
import net.mcreator.tobaccoproducts.item.CaptainsWatchItem;
import net.mcreator.tobaccoproducts.item.MacVillagerNavyFlakeItem;
import net.mcreator.tobaccoproducts.item.PipeTobacco7SeasItem;
import net.mcreator.tobaccoproducts.item.ManchesterItem;
import net.mcreator.tobaccoproducts.item.JingLingItem;
import net.mcreator.tobaccoproducts.item.PZItem;
import net.mcreator.tobaccoproducts.item.ArcadiaLighthouseItem;
import net.mcreator.tobaccoproducts.item.ApollonSoyuzItem;
import net.mcreator.tobaccoproducts.item.NicoTimeItem;
import net.mcreator.tobaccoproducts.item.ArthurtsPremiumItem;
import net.mcreator.tobaccoproducts.item.RadomskieItem;
import net.mcreator.tobaccoproducts.item.VoyageChocoItem;
import net.mcreator.tobaccoproducts.item.VoyageMintItem;
import net.mcreator.tobaccoproducts.item.VoyageNaturalLightItem;
import net.mcreator.tobaccoproducts.item.VoyageNaturalItem;
import net.mcreator.tobaccoproducts.item.Santiago99Item;
import net.mcreator.tobaccoproducts.item.SavannaSummerPackItem;
import net.mcreator.tobaccoproducts.item.SavannaSundayPackItem;
import net.mcreator.tobaccoproducts.item.NativeAgateItem;
import net.mcreator.tobaccoproducts.item.NativeDarkBlueItem;
import net.mcreator.tobaccoproducts.item.NativeCeladonItem;
import net.mcreator.tobaccoproducts.item.NativeYellowItem;
import net.mcreator.tobaccoproducts.item.NativeDarkGreenItem;
import net.mcreator.tobaccoproducts.item.NativeBlackItem;
import net.mcreator.tobaccoproducts.item.NativeTurquoiseItem;
import net.mcreator.tobaccoproducts.item.NativeBlueItem;
import net.mcreator.tobaccoproducts.item.BlackWitherAfterdinnerPackItem;
import net.mcreator.tobaccoproducts.item.BlackWitherCherryPackItem;
import net.mcreator.tobaccoproducts.item.BlacWitherFinestPackItem;
import net.mcreator.tobaccoproducts.item.BlacWitherSpecialPackItem;
import net.mcreator.tobaccoproducts.item.LlamaActive2PackItem;
import net.mcreator.tobaccoproducts.item.LlamaMentholPackItem;
import net.mcreator.tobaccoproducts.item.LlamaLightPackItem;
import net.mcreator.tobaccoproducts.item.LlamaNFPackItem;
import net.mcreator.tobaccoproducts.item.LlamaPackItem;
import net.mcreator.tobaccoproducts.item.HeimatCigarettesItem;
import net.mcreator.tobaccoproducts.item.NewShorePackItem;
import net.mcreator.tobaccoproducts.item.SmoothBlueItem;
import net.mcreator.tobaccoproducts.item.RedStrikesItem;
import net.mcreator.tobaccoproducts.item.CowboyDoublePackItem;
import net.mcreator.tobaccoproducts.item.MentholCigarettePackItem;
import net.minecraft.inventory.container.Slot;
import net.minecraft.util.IItemProvider;
import net.minecraft.item.ItemStack;
import net.mcreator.tobaccoproducts.item.CigarettePackItem;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.entity.Entity;
import java.util.HashMap;
import net.mcreator.tobaccoproducts.SmokingmodModElements.ModElement;
import net.mcreator.tobaccoproducts.SmokingmodModElements;

@Tag
public class UpdateShopProcedure extends SmokingmodModElements.ModElement
{
    public UpdateShopProcedure(final SmokingmodModElements instance) {
        super(instance, 438);
    }
    
    public static void executeProcedure(final HashMap<String, Object> dependencies) {
        if (dependencies.get("entity") == null) {
            System.err.println("Failed to load dependency entity for procedure UpdateShop!");
            return;
        }
        if (dependencies.get("x") == null) {
            System.err.println("Failed to load dependency x for procedure UpdateShop!");
            return;
        }
        if (dependencies.get("y") == null) {
            System.err.println("Failed to load dependency y for procedure UpdateShop!");
            return;
        }
        if (dependencies.get("z") == null) {
            System.err.println("Failed to load dependency z for procedure UpdateShop!");
            return;
        }
        if (dependencies.get("world") == null) {
            System.err.println("Failed to load dependency world for procedure UpdateShop!");
            return;
        }
        final Entity entity = dependencies.get("entity");
        final int x = dependencies.get("x");
        final int y = dependencies.get("y");
        final int z = dependencies.get("z");
        final World world = dependencies.get("world");
        if (new Object() {
            public double getValue(final BlockPos pos, final String tag) {
                final TileEntity tileEntity = world.func_175625_s(pos);
                if (tileEntity != null) {
                    return tileEntity.getTileData().func_74769_h(tag);
                }
                return -1.0;
            }
        }.getValue(new BlockPos(x, y, z), "category") == 0.0) {
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 0.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)CigarettePackItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 5.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 1.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)MentholCigarettePackItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 5.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 2.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)CowboyDoublePackItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 7.5);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 3.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)RedStrikesItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 8.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 4.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)SmoothBlueItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 8.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 5.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)NewShorePackItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 4.5);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 6.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)HeimatCigarettesItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 7.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 7.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)LlamaPackItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 5.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 8.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)LlamaNFPackItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 6.5);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 9.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)LlamaLightPackItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 5.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 10.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)LlamaMentholPackItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 6.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 11.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)LlamaActive2PackItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 6.5);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 12.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)BlacWitherSpecialPackItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 11.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 13.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)BlacWitherFinestPackItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 11.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 14.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)BlackWitherCherryPackItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 11.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 15.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)BlackWitherAfterdinnerPackItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 11.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 16.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)NativeBlueItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 8.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 17.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)NativeTurquoiseItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 8.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 18.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)NativeBlackItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 9.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 19.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)NativeDarkGreenItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 8.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 20.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)NativeYellowItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 8.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 21.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)NativeCeladonItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 8.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 22.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)NativeDarkBlueItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 8.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 23.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)NativeAgateItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 11.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 24.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)SavannaSundayPackItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 9.5);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 25.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)SavannaSummerPackItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 9.5);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 26.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)Santiago99Item.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 7.5);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 27.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)VoyageNaturalItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 7.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 28.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)VoyageNaturalLightItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 7.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 29.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)VoyageMintItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 7.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 30.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)VoyageChocoItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 8.5);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 31.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)RadomskieItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 5.5);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 32.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)ArthurtsPremiumItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 9.5);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 33.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)NicoTimeItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 6.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 34.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)ApollonSoyuzItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 4.5);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 35.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)ArcadiaLighthouseItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 5.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 36.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)PZItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 1.5);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 37.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)JingLingItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 2.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 38.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)ManchesterItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 2.5);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
        }
        if (new Object() {
            public double getValue(final BlockPos pos, final String tag) {
                final TileEntity tileEntity = world.func_175625_s(pos);
                if (tileEntity != null) {
                    return tileEntity.getTileData().func_74769_h(tag);
                }
                return -1.0;
            }
        }.getValue(new BlockPos(x, y, z), "category") == 2.0) {
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 0.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)PipeTobacco7SeasItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 9.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 1.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)MacVillagerNavyFlakeItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 15.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 2.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)CaptainsWatchItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 12.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 3.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)FirstEncounterItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 12.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 4.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)NarrowWellItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 14.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 5.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)PioneerRoadItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 14.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
        }
        if (new Object() {
            public double getValue(final BlockPos pos, final String tag) {
                final TileEntity tileEntity = world.func_175625_s(pos);
                if (tileEntity != null) {
                    return tileEntity.getTileData().func_74769_h(tag);
                }
                return -1.0;
            }
        }.getValue(new BlockPos(x, y, z), "category") == 1.0) {
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 0.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)RomeoJulietCoronaItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 5.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 1.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)RomeoJulietCoronaBoxItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 50.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 2.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)WildWestItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 4.5);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 3.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)WildWestBoxItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 45.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 4.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)LucasItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 6.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 5.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)LucasBoxItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 60.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 6.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)JoseItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 15.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 7.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)JoseBoxItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 150.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 8.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)CarlosItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 12.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 9.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)CarlosBoxItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 120.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
        }
        if (new Object() {
            public double getValue(final BlockPos pos, final String tag) {
                final TileEntity tileEntity = world.func_175625_s(pos);
                if (tileEntity != null) {
                    return tileEntity.getTileData().func_74769_h(tag);
                }
                return -1.0;
            }
        }.getValue(new BlockPos(x, y, z), "category") == 3.0) {
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 0.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)LyntMintItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 10.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 1.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)LyntMintStrongItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 10.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 2.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)LyntLiquoriceItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 10.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 3.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)TundraSpiritCitrusBerryItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 10.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
        }
        if (new Object() {
            public double getValue(final BlockPos pos, final String tag) {
                final TileEntity tileEntity = world.func_175625_s(pos);
                if (tileEntity != null) {
                    return tileEntity.getTileData().func_74769_h(tag);
                }
                return -1.0;
            }
        }.getValue(new BlockPos(x, y, z), "category") == 4.0 && new Object() {
            public double getValue(final BlockPos pos, final String tag) {
                final TileEntity tileEntity = world.func_175625_s(pos);
                if (tileEntity != null) {
                    return tileEntity.getTileData().func_74769_h(tag);
                }
                return -1.0;
            }
        }.getValue(new BlockPos(x, y, z), "select") == 0.0) {
            if (entity instanceof PlayerEntity) {
                final Container _current = ((PlayerEntity)entity).field_71070_bA;
                if (_current instanceof Supplier) {
                    final Object invobj = ((Supplier)_current).get();
                    if (invobj instanceof Map) {
                        final ItemStack _setstack = new ItemStack((IItemProvider)Blocks.field_196655_f, 1);
                        _setstack.func_190920_e(1);
                        ((Map)invobj).get(1).func_75215_d(_setstack);
                        _current.func_75142_b();
                    }
                }
            }
            if (!world.field_72995_K) {
                final BlockPos _bp = new BlockPos(x, y, z);
                final TileEntity _tileEntity = world.func_175625_s(_bp);
                final BlockState _bs = world.func_180495_p(_bp);
                if (_tileEntity != null) {
                    _tileEntity.getTileData().func_74780_a("price", 1.0);
                }
                world.func_184138_a(_bp, _bs, _bs, 3);
            }
        }
        if (new Object() {
            public double getValue(final BlockPos pos, final String tag) {
                final TileEntity tileEntity = world.func_175625_s(pos);
                if (tileEntity != null) {
                    return tileEntity.getTileData().func_74769_h(tag);
                }
                return -1.0;
            }
        }.getValue(new BlockPos(x, y, z), "category") == 5.0) {
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 0.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)TobaccoSeedItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 0.5);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 1.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)BurleySeedsItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 0.5);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 2.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)TobaccoLeafItemItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 1.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
            if (new Object() {
                public double getValue(final BlockPos pos, final String tag) {
                    final TileEntity tileEntity = world.func_175625_s(pos);
                    if (tileEntity != null) {
                        return tileEntity.getTileData().func_74769_h(tag);
                    }
                    return -1.0;
                }
            }.getValue(new BlockPos(x, y, z), "select") == 3.0) {
                if (entity instanceof PlayerEntity) {
                    final Container _current = ((PlayerEntity)entity).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            final ItemStack _setstack = new ItemStack((IItemProvider)BurleyLeafItemItem.block, 1);
                            _setstack.func_190920_e(1);
                            ((Map)invobj).get(1).func_75215_d(_setstack);
                            _current.func_75142_b();
                        }
                    }
                }
                if (!world.field_72995_K) {
                    final BlockPos _bp = new BlockPos(x, y, z);
                    final TileEntity _tileEntity = world.func_175625_s(_bp);
                    final BlockState _bs = world.func_180495_p(_bp);
                    if (_tileEntity != null) {
                        _tileEntity.getTileData().func_74780_a("price", 1.0);
                    }
                    world.func_184138_a(_bp, _bs, _bs, 3);
                }
            }
        }
    }
}
