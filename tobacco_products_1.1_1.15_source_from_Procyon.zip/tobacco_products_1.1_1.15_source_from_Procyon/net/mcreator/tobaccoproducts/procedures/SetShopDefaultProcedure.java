// 
// Decompiled by Procyon v0.5.36
// 

package net.mcreator.tobaccoproducts.procedures;

import net.minecraft.block.BlockState;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import java.util.HashMap;
import net.mcreator.tobaccoproducts.SmokingmodModElements.ModElement;
import net.mcreator.tobaccoproducts.SmokingmodModElements;

@Tag
public class SetShopDefaultProcedure extends SmokingmodModElements.ModElement
{
    public SetShopDefaultProcedure(final SmokingmodModElements instance) {
        super(instance, 444);
    }
    
    public static void executeProcedure(final HashMap<String, Object> dependencies) {
        if (dependencies.get("x") == null) {
            System.err.println("Failed to load dependency x for procedure SetShopDefault!");
            return;
        }
        if (dependencies.get("y") == null) {
            System.err.println("Failed to load dependency y for procedure SetShopDefault!");
            return;
        }
        if (dependencies.get("z") == null) {
            System.err.println("Failed to load dependency z for procedure SetShopDefault!");
            return;
        }
        if (dependencies.get("world") == null) {
            System.err.println("Failed to load dependency world for procedure SetShopDefault!");
            return;
        }
        final int x = dependencies.get("x");
        final int y = dependencies.get("y");
        final int z = dependencies.get("z");
        final World world = dependencies.get("world");
        if (!world.field_72995_K) {
            final BlockPos _bp = new BlockPos(x, y, z);
            final TileEntity _tileEntity = world.func_175625_s(_bp);
            final BlockState _bs = world.func_180495_p(_bp);
            if (_tileEntity != null) {
                _tileEntity.getTileData().func_74780_a("category", 0.0);
            }
            world.func_184138_a(_bp, _bs, _bs, 3);
        }
        if (!world.field_72995_K) {
            final BlockPos _bp = new BlockPos(x, y, z);
            final TileEntity _tileEntity = world.func_175625_s(_bp);
            final BlockState _bs = world.func_180495_p(_bp);
            if (_tileEntity != null) {
                _tileEntity.getTileData().func_74780_a("select", 0.0);
            }
            world.func_184138_a(_bp, _bs, _bs, 3);
        }
    }
}
