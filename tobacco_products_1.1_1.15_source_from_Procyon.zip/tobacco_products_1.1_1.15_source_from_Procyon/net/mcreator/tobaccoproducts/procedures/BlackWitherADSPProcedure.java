// 
// Decompiled by Procyon v0.5.36
// 

package net.mcreator.tobaccoproducts.procedures;

import net.minecraft.entity.Entity;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.command.CommandSource;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.world.server.ServerWorld;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import net.minecraft.command.ICommandSource;
import net.minecraft.world.World;
import java.util.HashMap;
import net.mcreator.tobaccoproducts.SmokingmodModElements.ModElement;
import net.mcreator.tobaccoproducts.SmokingmodModElements;

@Tag
public class BlackWitherADSPProcedure extends SmokingmodModElements.ModElement
{
    public BlackWitherADSPProcedure(final SmokingmodModElements instance) {
        super(instance, 274);
    }
    
    public static void executeProcedure(final HashMap<String, Object> dependencies) {
        if (dependencies.get("x") == null) {
            System.err.println("Failed to load dependency x for procedure BlackWitherADSP!");
            return;
        }
        if (dependencies.get("y") == null) {
            System.err.println("Failed to load dependency y for procedure BlackWitherADSP!");
            return;
        }
        if (dependencies.get("z") == null) {
            System.err.println("Failed to load dependency z for procedure BlackWitherADSP!");
            return;
        }
        if (dependencies.get("world") == null) {
            System.err.println("Failed to load dependency world for procedure BlackWitherADSP!");
            return;
        }
        final int x = dependencies.get("x");
        final int y = dependencies.get("y");
        final int z = dependencies.get("z");
        final World world = dependencies.get("world");
        final double time_alive = 0.0;
        final double Y = 0.0;
        if (!world.field_72995_K && world.func_73046_m() != null) {
            world.func_73046_m().func_195571_aL().func_197059_a(new CommandSource(ICommandSource.field_213139_a_, new Vec3d((double)x, (double)y, (double)z), Vec2f.field_189974_a, (ServerWorld)world, 4, "", (ITextComponent)new StringTextComponent(""), world.func_73046_m(), (Entity)null).func_197031_a(), "execute at @e[type=smokingmod:entitybulletblack_wither_ads] run particle minecraft:campfire_cosy_smoke ~ ~ ~ 0.1 0.1 0.1 0.02 7 normal");
        }
        if (!world.field_72995_K && world.func_73046_m() != null) {
            world.func_73046_m().func_195571_aL().func_197059_a(new CommandSource(ICommandSource.field_213139_a_, new Vec3d((double)x, (double)y, (double)z), Vec2f.field_189974_a, (ServerWorld)world, 4, "", (ITextComponent)new StringTextComponent(""), world.func_73046_m(), (Entity)null).func_197031_a(), "/kill @e[type=smokingmod:entitybulletblack_wither_ads]");
        }
    }
}
