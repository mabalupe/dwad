// 
// Decompiled by Procyon v0.5.36
// 

package net.mcreator.tobaccoproducts.procedures;

import net.minecraft.util.IItemProvider;
import net.minecraft.item.ItemStack;
import net.mcreator.tobaccoproducts.item.BurleySeedsItem;
import net.minecraft.entity.player.PlayerEntity;
import net.mcreator.tobaccoproducts.block.BurleyPlant0Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.block.Blocks;
import net.minecraft.world.World;
import net.minecraft.entity.Entity;
import java.util.HashMap;
import net.mcreator.tobaccoproducts.SmokingmodModElements.ModElement;
import net.mcreator.tobaccoproducts.SmokingmodModElements;

@Tag
public class BurleyPlantOnSoilProcedure extends SmokingmodModElements.ModElement
{
    public BurleyPlantOnSoilProcedure(final SmokingmodModElements instance) {
        super(instance, 140);
    }
    
    public static void executeProcedure(final HashMap<String, Object> dependencies) {
        if (dependencies.get("entity") == null) {
            System.err.println("Failed to load dependency entity for procedure BurleyPlantOnSoil!");
            return;
        }
        if (dependencies.get("x") == null) {
            System.err.println("Failed to load dependency x for procedure BurleyPlantOnSoil!");
            return;
        }
        if (dependencies.get("y") == null) {
            System.err.println("Failed to load dependency y for procedure BurleyPlantOnSoil!");
            return;
        }
        if (dependencies.get("z") == null) {
            System.err.println("Failed to load dependency z for procedure BurleyPlantOnSoil!");
            return;
        }
        if (dependencies.get("world") == null) {
            System.err.println("Failed to load dependency world for procedure BurleyPlantOnSoil!");
            return;
        }
        final Entity entity = dependencies.get("entity");
        final int x = dependencies.get("x");
        final int y = dependencies.get("y");
        final int z = dependencies.get("z");
        final World world = dependencies.get("world");
        if (Blocks.field_150458_ak.func_176223_P().func_177230_c() == world.func_180495_p(new BlockPos(x, y, z)).func_177230_c() && world.func_180495_p(new BlockPos(x, y + 1, z)).func_177230_c() == Blocks.field_150350_a.func_176223_P().func_177230_c()) {
            world.func_180501_a(new BlockPos(x, y + 1, z), BurleyPlant0Block.block.func_176223_P(), 3);
            if (!(entity instanceof PlayerEntity) || !((PlayerEntity)entity).field_71075_bZ.field_75098_d) {
                if (entity instanceof PlayerEntity) {
                    ((PlayerEntity)entity).field_71071_by.func_195408_a(p -> new ItemStack((IItemProvider)BurleySeedsItem.block, 1).func_77973_b() == p.func_77973_b(), 1);
                }
            }
        }
    }
}
