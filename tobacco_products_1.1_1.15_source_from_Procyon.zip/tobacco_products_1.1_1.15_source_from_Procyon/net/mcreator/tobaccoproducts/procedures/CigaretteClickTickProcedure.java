// 
// Decompiled by Procyon v0.5.36
// 

package net.mcreator.tobaccoproducts.procedures;

import net.mcreator.tobaccoproducts.SmokingmodModVariables;
import net.minecraft.world.World;
import net.minecraft.item.ItemStack;
import java.util.HashMap;
import net.mcreator.tobaccoproducts.SmokingmodModElements.ModElement;
import net.mcreator.tobaccoproducts.SmokingmodModElements;

@Tag
public class CigaretteClickTickProcedure extends SmokingmodModElements.ModElement
{
    public CigaretteClickTickProcedure(final SmokingmodModElements instance) {
        super(instance, 172);
    }
    
    public static void executeProcedure(final HashMap<String, Object> dependencies) {
        if (dependencies.get("itemstack") == null) {
            System.err.println("Failed to load dependency itemstack for procedure CigaretteClickTick!");
            return;
        }
        if (dependencies.get("world") == null) {
            System.err.println("Failed to load dependency world for procedure CigaretteClickTick!");
            return;
        }
        final ItemStack itemstack = dependencies.get("itemstack");
        final World world = dependencies.get("world");
        if (SmokingmodModVariables.WorldVariables.get(world).click == 1.0) {
            SmokingmodModVariables.WorldVariables.get(world).click = 0.0;
            SmokingmodModVariables.WorldVariables.get(world).syncData(world);
            if (itemstack.func_196082_o().func_74769_h("click") < 2.0) {
                itemstack.func_196082_o().func_74780_a("click", itemstack.func_196082_o().func_74769_h("click") + 1.0);
            }
        }
    }
}
