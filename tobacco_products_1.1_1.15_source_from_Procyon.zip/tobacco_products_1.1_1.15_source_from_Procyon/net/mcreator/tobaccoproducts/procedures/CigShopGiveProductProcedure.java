// 
// Decompiled by Procyon v0.5.36
// 

package net.mcreator.tobaccoproducts.procedures;

import net.mcreator.tobaccoproducts.SmokingmodModVariables;
import net.minecraft.util.IItemProvider;
import net.minecraft.item.Items;
import net.minecraft.inventory.container.Container;
import net.minecraft.inventory.container.Slot;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import net.minecraft.entity.Entity;
import java.util.HashMap;
import net.mcreator.tobaccoproducts.SmokingmodModElements.ModElement;
import net.mcreator.tobaccoproducts.SmokingmodModElements;

@Tag
public class CigShopGiveProductProcedure extends SmokingmodModElements.ModElement
{
    public CigShopGiveProductProcedure(final SmokingmodModElements instance) {
        super(instance, 126);
    }
    
    public static void executeProcedure(final HashMap<String, Object> dependencies) {
        if (dependencies.get("entity") == null) {
            System.err.println("Failed to load dependency entity for procedure CigShopGiveProduct!");
            return;
        }
        if (dependencies.get("world") == null) {
            System.err.println("Failed to load dependency world for procedure CigShopGiveProduct!");
            return;
        }
        final Entity entity = dependencies.get("entity");
        final World world = dependencies.get("world");
        if (new Object() {
            public ItemStack getItemStack(final int sltid) {
                final Entity _ent = entity;
                if (_ent instanceof ServerPlayerEntity) {
                    final Container _current = ((ServerPlayerEntity)_ent).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            return ((Map)invobj).get(sltid).func_75211_c();
                        }
                    }
                }
                return ItemStack.field_190927_a;
            }
        }.getItemStack(0).func_77973_b() == new ItemStack((IItemProvider)Items.field_151042_j, 1).func_77973_b()) {
            ++SmokingmodModVariables.WorldVariables.get(world).cash;
            SmokingmodModVariables.WorldVariables.get(world).syncData(world);
            final Entity _ent = entity;
            if (_ent instanceof ServerPlayerEntity) {
                final Container _current = ((ServerPlayerEntity)_ent).field_71070_bA;
                if (_current instanceof Supplier) {
                    final Object invobj = ((Supplier)_current).get();
                    if (invobj instanceof Map) {
                        ((Map)invobj).get(0).func_75209_a(1);
                        _current.func_75142_b();
                    }
                }
            }
        }
        if (new Object() {
            public ItemStack getItemStack(final int sltid) {
                final Entity _ent = entity;
                if (_ent instanceof ServerPlayerEntity) {
                    final Container _current = ((ServerPlayerEntity)_ent).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            return ((Map)invobj).get(sltid).func_75211_c();
                        }
                    }
                }
                return ItemStack.field_190927_a;
            }
        }.getItemStack(0).func_77973_b() == new ItemStack((IItemProvider)Items.field_151043_k, 1).func_77973_b()) {
            SmokingmodModVariables.WorldVariables.get(world).cash += 10.0;
            SmokingmodModVariables.WorldVariables.get(world).syncData(world);
            final Entity _ent = entity;
            if (_ent instanceof ServerPlayerEntity) {
                final Container _current = ((ServerPlayerEntity)_ent).field_71070_bA;
                if (_current instanceof Supplier) {
                    final Object invobj = ((Supplier)_current).get();
                    if (invobj instanceof Map) {
                        ((Map)invobj).get(0).func_75209_a(1);
                        _current.func_75142_b();
                    }
                }
            }
        }
        if (new Object() {
            public ItemStack getItemStack(final int sltid) {
                final Entity _ent = entity;
                if (_ent instanceof ServerPlayerEntity) {
                    final Container _current = ((ServerPlayerEntity)_ent).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            return ((Map)invobj).get(sltid).func_75211_c();
                        }
                    }
                }
                return ItemStack.field_190927_a;
            }
        }.getItemStack(0).func_77973_b() == new ItemStack((IItemProvider)Items.field_151166_bC, 1).func_77973_b()) {
            SmokingmodModVariables.WorldVariables.get(world).cash += 20.0;
            SmokingmodModVariables.WorldVariables.get(world).syncData(world);
            final Entity _ent = entity;
            if (_ent instanceof ServerPlayerEntity) {
                final Container _current = ((ServerPlayerEntity)_ent).field_71070_bA;
                if (_current instanceof Supplier) {
                    final Object invobj = ((Supplier)_current).get();
                    if (invobj instanceof Map) {
                        ((Map)invobj).get(0).func_75209_a(1);
                        _current.func_75142_b();
                    }
                }
            }
        }
        if (new Object() {
            public ItemStack getItemStack(final int sltid) {
                final Entity _ent = entity;
                if (_ent instanceof ServerPlayerEntity) {
                    final Container _current = ((ServerPlayerEntity)_ent).field_71070_bA;
                    if (_current instanceof Supplier) {
                        final Object invobj = ((Supplier)_current).get();
                        if (invobj instanceof Map) {
                            return ((Map)invobj).get(sltid).func_75211_c();
                        }
                    }
                }
                return ItemStack.field_190927_a;
            }
        }.getItemStack(0).func_77973_b() == new ItemStack((IItemProvider)Items.field_151045_i, 1).func_77973_b()) {
            SmokingmodModVariables.WorldVariables.get(world).cash += 50.0;
            SmokingmodModVariables.WorldVariables.get(world).syncData(world);
            final Entity _ent = entity;
            if (_ent instanceof ServerPlayerEntity) {
                final Container _current = ((ServerPlayerEntity)_ent).field_71070_bA;
                if (_current instanceof Supplier) {
                    final Object invobj = ((Supplier)_current).get();
                    if (invobj instanceof Map) {
                        ((Map)invobj).get(0).func_75209_a(1);
                        _current.func_75142_b();
                    }
                }
            }
        }
    }
}
