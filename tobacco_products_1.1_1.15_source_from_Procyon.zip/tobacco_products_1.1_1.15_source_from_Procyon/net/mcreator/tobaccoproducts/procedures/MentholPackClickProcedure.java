// 
// Decompiled by Procyon v0.5.36
// 

package net.mcreator.tobaccoproducts.procedures;

import net.minecraftforge.items.ItemHandlerHelper;
import net.minecraft.util.IItemProvider;
import net.mcreator.tobaccoproducts.item.MentholCigaretteItem;
import net.minecraft.entity.player.ServerPlayerEntity;
import java.util.Random;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.Entity;
import java.util.HashMap;
import net.mcreator.tobaccoproducts.SmokingmodModElements.ModElement;
import net.mcreator.tobaccoproducts.SmokingmodModElements;

@Tag
public class MentholPackClickProcedure extends SmokingmodModElements.ModElement
{
    public MentholPackClickProcedure(final SmokingmodModElements instance) {
        super(instance, 166);
    }
    
    public static void executeProcedure(final HashMap<String, Object> dependencies) {
        if (dependencies.get("entity") == null) {
            System.err.println("Failed to load dependency entity for procedure MentholPackClick!");
            return;
        }
        if (dependencies.get("itemstack") == null) {
            System.err.println("Failed to load dependency itemstack for procedure MentholPackClick!");
            return;
        }
        final Entity entity = dependencies.get("entity");
        final ItemStack itemstack = dependencies.get("itemstack");
        if (entity instanceof PlayerEntity) {
            ((PlayerEntity)entity).func_184811_cZ().func_185145_a(itemstack.func_77973_b(), 10);
        }
        final ItemStack _ist = itemstack;
        if (_ist.func_96631_a(1, new Random(), (ServerPlayerEntity)null)) {
            _ist.func_190918_g(1);
            _ist.func_196085_b(0);
        }
        if (entity instanceof PlayerEntity) {
            final ItemStack _setstack = new ItemStack((IItemProvider)MentholCigaretteItem.block, 1);
            _setstack.func_190920_e(1);
            ItemHandlerHelper.giveItemToPlayer((PlayerEntity)entity, _setstack);
        }
    }
}
