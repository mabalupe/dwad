// 
// Decompiled by Procyon v0.5.36
// 

package net.mcreator.tobaccoproducts.procedures;

import net.minecraft.server.MinecraftServer;
import net.minecraft.entity.player.ServerPlayerEntity;
import java.util.Random;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.StringTextComponent;
import net.minecraftforge.fml.server.ServerLifecycleHooks;
import net.mcreator.tobaccoproducts.SmokingmodModVariables;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.World;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.Entity;
import java.util.HashMap;
import net.mcreator.tobaccoproducts.SmokingmodModElements.ModElement;
import net.mcreator.tobaccoproducts.SmokingmodModElements;

@Tag
public class VoyageNaturalLightSmokeProcedure extends SmokingmodModElements.ModElement
{
    public VoyageNaturalLightSmokeProcedure(final SmokingmodModElements instance) {
        super(instance, 396);
    }
    
    public static void executeProcedure(final HashMap<String, Object> dependencies) {
        if (dependencies.get("entity") == null) {
            System.err.println("Failed to load dependency entity for procedure VoyageNaturalLightSmoke!");
            return;
        }
        if (dependencies.get("itemstack") == null) {
            System.err.println("Failed to load dependency itemstack for procedure VoyageNaturalLightSmoke!");
            return;
        }
        if (dependencies.get("world") == null) {
            System.err.println("Failed to load dependency world for procedure VoyageNaturalLightSmoke!");
            return;
        }
        final Entity entity = dependencies.get("entity");
        final ItemStack itemstack = dependencies.get("itemstack");
        final World world = dependencies.get("world");
        double flavour = 0.0;
        final double X = 0.0;
        final double Z = 0.0;
        final double Y = 0.0;
        if (!world.field_72995_K) {
            if (entity instanceof PlayerEntity) {
                ((PlayerEntity)entity).func_184811_cZ().func_185145_a(itemstack.func_77973_b(), 30);
            }
            itemstack.func_196082_o().func_74780_a("puffs", itemstack.func_196082_o().func_74769_h("puffs") + 1.0);
            SmokingmodModVariables.MapVariables.get(world).nicotine_level += 20.0;
            SmokingmodModVariables.MapVariables.get(world).syncData(world);
            if (Math.random() < 0.1) {
                flavour = Math.random();
                if (flavour < 1.0 && flavour > 0.6) {
                    final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                    if (mcserv != null) {
                        mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste pleasant creamy smoke."));
                    }
                }
                if (flavour <= 0.6 && flavour > 0.2) {
                    final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                    if (mcserv != null) {
                        mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste sweet honey flavouring."));
                    }
                }
                if (flavour <= 0.2 && flavour > 0.1) {
                    final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                    if (mcserv != null) {
                        mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste fruity notes."));
                    }
                }
                if (flavour <= 0.1) {
                    final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                    if (mcserv != null) {
                        mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can feel light lung hit."));
                    }
                }
            }
            if (Math.random() < 0.2 && entity instanceof LivingEntity) {
                ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76428_l, 140, 0, true, false));
            }
            if (itemstack.func_196082_o().func_74769_h("puffs") >= 10.0) {
                final ItemStack _ist = itemstack;
                if (_ist.func_96631_a(1, new Random(), (ServerPlayerEntity)null)) {
                    _ist.func_190918_g(1);
                    _ist.func_196085_b(0);
                }
                if (Math.random() < 0.6 && entity instanceof LivingEntity) {
                    ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_188425_z, 1200, 0, true, false));
                }
            }
        }
    }
}
