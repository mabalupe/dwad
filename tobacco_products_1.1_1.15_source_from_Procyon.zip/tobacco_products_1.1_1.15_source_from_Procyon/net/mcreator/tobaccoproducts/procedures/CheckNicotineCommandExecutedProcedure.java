// 
// Decompiled by Procyon v0.5.36
// 

package net.mcreator.tobaccoproducts.procedures;

import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.StringTextComponent;
import net.mcreator.tobaccoproducts.SmokingmodModVariables;
import net.minecraftforge.fml.server.ServerLifecycleHooks;
import net.minecraft.world.World;
import java.util.HashMap;
import net.mcreator.tobaccoproducts.SmokingmodModElements.ModElement;
import net.mcreator.tobaccoproducts.SmokingmodModElements;

@Tag
public class CheckNicotineCommandExecutedProcedure extends SmokingmodModElements.ModElement
{
    public CheckNicotineCommandExecutedProcedure(final SmokingmodModElements instance) {
        super(instance, 100);
    }
    
    public static void executeProcedure(final HashMap<String, Object> dependencies) {
        if (dependencies.get("world") == null) {
            System.err.println("Failed to load dependency world for procedure CheckNicotineCommandExecuted!");
            return;
        }
        final World world = dependencies.get("world");
        final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
        if (mcserv != null) {
            mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("Nicotine level: " + SmokingmodModVariables.MapVariables.get(world).nicotine_level));
        }
    }
}
