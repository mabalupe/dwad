// 
// Decompiled by Procyon v0.5.36
// 

package net.mcreator.tobaccoproducts.procedures;

import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraft.server.MinecraftServer;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.StringTextComponent;
import net.minecraftforge.fml.server.ServerLifecycleHooks;
import net.mcreator.tobaccoproducts.SmokingmodModVariables;
import net.minecraft.world.World;
import net.minecraft.entity.Entity;
import java.util.HashMap;
import net.minecraftforge.common.MinecraftForge;
import net.mcreator.tobaccoproducts.SmokingmodModElements.ModElement;
import net.mcreator.tobaccoproducts.SmokingmodModElements;

@Tag
public class SmokelessChewProcedure extends SmokingmodModElements.ModElement
{
    public SmokelessChewProcedure(final SmokingmodModElements instance) {
        super(instance, 477);
        MinecraftForge.EVENT_BUS.register((Object)this);
    }
    
    public static void executeProcedure(final HashMap<String, Object> dependencies) {
        if (dependencies.get("entity") == null) {
            System.err.println("Failed to load dependency entity for procedure SmokelessChew!");
            return;
        }
        if (dependencies.get("world") == null) {
            System.err.println("Failed to load dependency world for procedure SmokelessChew!");
            return;
        }
        final Entity entity = dependencies.get("entity");
        final World world = dependencies.get("world");
        double flavour = 0.0;
        if (!world.field_72995_K && SmokingmodModVariables.MapVariables.get(world).Smokeless > 0.0) {
            if (SmokingmodModVariables.MapVariables.get(world).rand_chew_time == 0.0) {
                SmokingmodModVariables.MapVariables.get(world).rand_chew_time = Math.random() + 0.5;
                SmokingmodModVariables.MapVariables.get(world).syncData(world);
                SmokingmodModVariables.MapVariables.get(world).rand_chew_time_pick = SmokingmodModVariables.MapVariables.get(world).rand_chew_time - 0.06;
                SmokingmodModVariables.MapVariables.get(world).syncData(world);
            }
            if (SmokingmodModVariables.MapVariables.get(world).rand_chew_time > 1.0) {
                SmokingmodModVariables.MapVariables.get(world).rand_chew_time = 1.0;
                SmokingmodModVariables.MapVariables.get(world).syncData(world);
                SmokingmodModVariables.MapVariables.get(world).rand_chew_time_pick = 0.94;
                SmokingmodModVariables.MapVariables.get(world).syncData(world);
            }
            ++SmokingmodModVariables.MapVariables.get(world).tick;
            SmokingmodModVariables.MapVariables.get(world).syncData(world);
            if (SmokingmodModVariables.MapVariables.get(world).tick >= 19.0) {
                SmokingmodModVariables.MapVariables.get(world).tick = 0.0;
                SmokingmodModVariables.MapVariables.get(world).syncData(world);
                ++SmokingmodModVariables.MapVariables.get(world).sec;
                SmokingmodModVariables.MapVariables.get(world).syncData(world);
                if (SmokingmodModVariables.MapVariables.get(world).sec >= 9.0) {
                    SmokingmodModVariables.MapVariables.get(world).rand_chew_time -= 0.01;
                    SmokingmodModVariables.MapVariables.get(world).syncData(world);
                    SmokingmodModVariables.MapVariables.get(world).sec = 0.0;
                    SmokingmodModVariables.MapVariables.get(world).syncData(world);
                    flavour = Math.random();
                    if (SmokingmodModVariables.MapVariables.get(world).rand_chew_time >= SmokingmodModVariables.MapVariables.get(world).rand_chew_time_pick - 0.001 && SmokingmodModVariables.MapVariables.get(world).rand_chew_time <= SmokingmodModVariables.MapVariables.get(world).rand_chew_time_pick + 0.001) {
                        flavour = 0.05;
                    }
                    if (SmokingmodModVariables.MapVariables.get(world).Smokeless == 1.0) {
                        if (flavour > 0.0 && flavour <= 0.025) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste mint."));
                            }
                            if (entity instanceof LivingEntity) {
                                ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76428_l, 40, 0, false, false));
                            }
                        }
                        if (flavour > 0.025 && flavour <= 0.05) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can feel slight tingling under the lip. "));
                            }
                            if (entity instanceof LivingEntity) {
                                ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76424_c, 400, 0, false, false));
                            }
                        }
                    }
                    if (SmokingmodModVariables.MapVariables.get(world).Smokeless == 2.0) {
                        if (flavour > 0.0 && flavour <= 0.0125) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste mint."));
                            }
                            if (entity instanceof LivingEntity) {
                                ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76428_l, 80, 0, false, false));
                            }
                        }
                        if (flavour > 0.0125 && flavour <= 0.025) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can feel coolness under the lip."));
                            }
                            if (entity instanceof LivingEntity) {
                                ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76424_c, 400, 0, false, false));
                            }
                        }
                        if (flavour > 0.025 && flavour <= 0.05) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can feel tingling under the lip. "));
                            }
                            if (entity instanceof LivingEntity) {
                                ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76424_c, 600, 0, false, false));
                            }
                        }
                    }
                    if (SmokingmodModVariables.MapVariables.get(world).Smokeless == 3.0) {
                        if (flavour > 0.0 && flavour <= 0.02) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste mint."));
                            }
                            if (entity instanceof LivingEntity) {
                                ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76424_c, 300, 0, false, false));
                            }
                        }
                        if (flavour > 0.02 && flavour <= 0.03) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can feel easy tingling under the lip. "));
                            }
                            if (entity instanceof LivingEntity) {
                                ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76424_c, 300, 0, false, false));
                            }
                        }
                        if (flavour > 0.03 && flavour <= 0.05) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste liquorice."));
                            }
                            if (entity instanceof LivingEntity) {
                                ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76428_l, 80, 1, false, false));
                            }
                        }
                    }
                    if (SmokingmodModVariables.MapVariables.get(world).Smokeless == 4.0) {
                        if (flavour > 0.0 && flavour <= 0.01) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste citrus."));
                            }
                            if (entity instanceof LivingEntity) {
                                ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76422_e, 300, 0, false, false));
                            }
                        }
                        if (flavour > 0.01 && flavour <= 0.02) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste blueberry."));
                            }
                            if (entity instanceof LivingEntity) {
                                ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_188425_z, 900, 0, false, false));
                            }
                        }
                        if (flavour > 0.02 && flavour <= 0.03) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can feel freshness"));
                            }
                            if (entity instanceof LivingEntity) {
                                ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76424_c, 300, 0, false, false));
                            }
                        }
                        if (flavour > 0.03 && flavour <= 0.05) {
                            final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                            if (mcserv != null) {
                                mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You can taste sweet tart."));
                            }
                            if (entity instanceof LivingEntity) {
                                ((LivingEntity)entity).func_195064_c(new EffectInstance(Effects.field_76428_l, 100, 1, false, false));
                            }
                        }
                    }
                    if (SmokingmodModVariables.MapVariables.get(world).rand_chew_time <= 0.0) {
                        final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
                        if (mcserv != null) {
                            mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("You take out your chew."));
                        }
                        SmokingmodModVariables.MapVariables.get(world).sec = 0.0;
                        SmokingmodModVariables.MapVariables.get(world).syncData(world);
                        SmokingmodModVariables.MapVariables.get(world).tick = 0.0;
                        SmokingmodModVariables.MapVariables.get(world).syncData(world);
                        SmokingmodModVariables.MapVariables.get(world).rand_chew_time = 0.0;
                        SmokingmodModVariables.MapVariables.get(world).syncData(world);
                        SmokingmodModVariables.MapVariables.get(world).Smokeless = 0.0;
                        SmokingmodModVariables.MapVariables.get(world).syncData(world);
                    }
                }
            }
        }
    }
    
    @SubscribeEvent
    public void onPlayerTick(final TickEvent.PlayerTickEvent event) {
        if (event.phase == TickEvent.Phase.END) {
            final Entity entity = (Entity)event.player;
            final World world = entity.field_70170_p;
            final int i = (int)entity.func_226277_ct_();
            final int j = (int)entity.func_226278_cu_();
            final int k = (int)entity.func_226281_cx_();
            final HashMap<String, Object> dependencies = new HashMap<String, Object>();
            dependencies.put("x", i);
            dependencies.put("y", j);
            dependencies.put("z", k);
            dependencies.put("world", world);
            dependencies.put("entity", entity);
            dependencies.put("event", event);
            executeProcedure(dependencies);
        }
    }
}
