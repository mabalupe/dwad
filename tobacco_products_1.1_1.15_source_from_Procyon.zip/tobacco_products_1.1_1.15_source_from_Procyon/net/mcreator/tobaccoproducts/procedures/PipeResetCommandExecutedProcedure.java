// 
// Decompiled by Procyon v0.5.36
// 

package net.mcreator.tobaccoproducts.procedures;

import net.mcreator.tobaccoproducts.SmokingmodModVariables;
import net.minecraft.world.World;
import java.util.HashMap;
import net.mcreator.tobaccoproducts.SmokingmodModElements.ModElement;
import net.mcreator.tobaccoproducts.SmokingmodModElements;

@Tag
public class PipeResetCommandExecutedProcedure extends SmokingmodModElements.ModElement
{
    public PipeResetCommandExecutedProcedure(final SmokingmodModElements instance) {
        super(instance, 422);
    }
    
    public static void executeProcedure(final HashMap<String, Object> dependencies) {
        if (dependencies.get("world") == null) {
            System.err.println("Failed to load dependency world for procedure PipeResetCommandExecuted!");
            return;
        }
        final World world = dependencies.get("world");
        SmokingmodModVariables.MapVariables.get(world).packtobacco = 0.0;
        SmokingmodModVariables.MapVariables.get(world).syncData(world);
    }
}
