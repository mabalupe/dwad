// 
// Decompiled by Procyon v0.5.36
// 

package net.mcreator.tobaccoproducts.procedures;

import net.mcreator.tobaccoproducts.item.NativeYellowCigItem;
import net.minecraftforge.items.ItemHandlerHelper;
import net.mcreator.tobaccoproducts.item.NativeYellowSItem;
import net.minecraft.util.IItemProvider;
import net.minecraft.item.ItemStack;
import net.mcreator.tobaccoproducts.item.MatchesItem;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.World;
import net.minecraft.entity.Entity;
import java.util.HashMap;
import net.mcreator.tobaccoproducts.SmokingmodModElements.ModElement;
import net.mcreator.tobaccoproducts.SmokingmodModElements;

@Tag
public class NativeYellowClickProcedure extends SmokingmodModElements.ModElement
{
    public NativeYellowClickProcedure(final SmokingmodModElements instance) {
        super(instance, 328);
    }
    
    public static void executeProcedure(final HashMap<String, Object> dependencies) {
        if (dependencies.get("entity") == null) {
            System.err.println("Failed to load dependency entity for procedure NativeYellowClick!");
            return;
        }
        if (dependencies.get("world") == null) {
            System.err.println("Failed to load dependency world for procedure NativeYellowClick!");
            return;
        }
        final Entity entity = dependencies.get("entity");
        final World world = dependencies.get("world");
        if (!world.field_72995_K && entity instanceof PlayerEntity && ((PlayerEntity)entity).field_71071_by.func_70431_c(new ItemStack((IItemProvider)MatchesItem.block, 1))) {
            if (entity instanceof PlayerEntity) {
                final ItemStack _setstack = new ItemStack((IItemProvider)NativeYellowSItem.block, 1);
                _setstack.func_190920_e(1);
                ItemHandlerHelper.giveItemToPlayer((PlayerEntity)entity, _setstack);
            }
            if (entity instanceof PlayerEntity) {
                ((PlayerEntity)entity).field_71071_by.func_195408_a(p -> new ItemStack((IItemProvider)NativeYellowCigItem.block, 1).func_77973_b() == p.func_77973_b(), 1);
            }
        }
    }
}
