// 
// Decompiled by Procyon v0.5.36
// 

package net.mcreator.tobaccoproducts.procedures;

import net.minecraft.entity.player.ServerPlayerEntity;
import java.util.Random;
import net.mcreator.tobaccoproducts.SmokingmodModVariables;
import net.minecraft.util.IItemProvider;
import net.mcreator.tobaccoproducts.item.PipeSItem;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.World;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.Entity;
import java.util.HashMap;
import net.mcreator.tobaccoproducts.SmokingmodModElements.ModElement;
import net.mcreator.tobaccoproducts.SmokingmodModElements;

@Tag
public class BurleyVirginiaDarkUnpackProcedure extends SmokingmodModElements.ModElement
{
    public BurleyVirginiaDarkUnpackProcedure(final SmokingmodModElements instance) {
        super(instance, 472);
    }
    
    public static void executeProcedure(final HashMap<String, Object> dependencies) {
        if (dependencies.get("entity") == null) {
            System.err.println("Failed to load dependency entity for procedure BurleyVirginiaDarkUnpack!");
            return;
        }
        if (dependencies.get("itemstack") == null) {
            System.err.println("Failed to load dependency itemstack for procedure BurleyVirginiaDarkUnpack!");
            return;
        }
        if (dependencies.get("world") == null) {
            System.err.println("Failed to load dependency world for procedure BurleyVirginiaDarkUnpack!");
            return;
        }
        final Entity entity = dependencies.get("entity");
        final ItemStack itemstack = dependencies.get("itemstack");
        final World world = dependencies.get("world");
        if (entity instanceof PlayerEntity) {
            ((PlayerEntity)entity).func_184811_cZ().func_185145_a(itemstack.func_77973_b(), 5);
        }
        if (!world.field_72995_K && entity instanceof PlayerEntity && ((PlayerEntity)entity).field_71071_by.func_70431_c(new ItemStack((IItemProvider)PipeSItem.block, 1)) && SmokingmodModVariables.MapVariables.get(world).packtobacco == 0.0) {
            SmokingmodModVariables.MapVariables.get(world).packtobacco = 8.0;
            SmokingmodModVariables.MapVariables.get(world).syncData(world);
            SmokingmodModVariables.MapVariables.get(world).print = false;
            SmokingmodModVariables.MapVariables.get(world).syncData(world);
            final ItemStack _ist = itemstack;
            if (_ist.func_96631_a(1, new Random(), (ServerPlayerEntity)null)) {
                _ist.func_190918_g(1);
                _ist.func_196085_b(0);
            }
        }
    }
}
