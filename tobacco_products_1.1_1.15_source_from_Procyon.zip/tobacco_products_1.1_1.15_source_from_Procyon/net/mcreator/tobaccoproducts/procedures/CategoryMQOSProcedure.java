// 
// Decompiled by Procyon v0.5.36
// 

package net.mcreator.tobaccoproducts.procedures;

import net.minecraft.block.BlockState;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.entity.Entity;
import java.util.HashMap;
import net.mcreator.tobaccoproducts.SmokingmodModElements.ModElement;
import net.mcreator.tobaccoproducts.SmokingmodModElements;

@Tag
public class CategoryMQOSProcedure extends SmokingmodModElements.ModElement
{
    public CategoryMQOSProcedure(final SmokingmodModElements instance) {
        super(instance, 443);
    }
    
    public static void executeProcedure(final HashMap<String, Object> dependencies) {
        if (dependencies.get("entity") == null) {
            System.err.println("Failed to load dependency entity for procedure CategoryMQOS!");
            return;
        }
        if (dependencies.get("x") == null) {
            System.err.println("Failed to load dependency x for procedure CategoryMQOS!");
            return;
        }
        if (dependencies.get("y") == null) {
            System.err.println("Failed to load dependency y for procedure CategoryMQOS!");
            return;
        }
        if (dependencies.get("z") == null) {
            System.err.println("Failed to load dependency z for procedure CategoryMQOS!");
            return;
        }
        if (dependencies.get("world") == null) {
            System.err.println("Failed to load dependency world for procedure CategoryMQOS!");
            return;
        }
        final Entity entity = dependencies.get("entity");
        final int x = dependencies.get("x");
        final int y = dependencies.get("y");
        final int z = dependencies.get("z");
        final World world = dependencies.get("world");
        if (!world.field_72995_K) {
            final BlockPos _bp = new BlockPos(x, y, z);
            final TileEntity _tileEntity = world.func_175625_s(_bp);
            final BlockState _bs = world.func_180495_p(_bp);
            if (_tileEntity != null) {
                _tileEntity.getTileData().func_74780_a("category", 4.0);
            }
            world.func_184138_a(_bp, _bs, _bs, 3);
        }
        if (!world.field_72995_K) {
            final BlockPos _bp = new BlockPos(x, y, z);
            final TileEntity _tileEntity = world.func_175625_s(_bp);
            final BlockState _bs = world.func_180495_p(_bp);
            if (_tileEntity != null) {
                _tileEntity.getTileData().func_74780_a("select", 0.0);
            }
            world.func_184138_a(_bp, _bs, _bs, 3);
        }
        final HashMap<String, Object> $_dependencies = new HashMap<String, Object>();
        $_dependencies.put("entity", entity);
        $_dependencies.put("x", x);
        $_dependencies.put("y", y);
        $_dependencies.put("z", z);
        $_dependencies.put("world", world);
        UpdateShopProcedure.executeProcedure($_dependencies);
    }
}
