// 
// Decompiled by Procyon v0.5.36
// 

package net.mcreator.tobaccoproducts.block;

import net.minecraftforge.common.PlantType;
import java.util.Collections;
import net.minecraft.util.IItemProvider;
import net.mcreator.tobaccoproducts.item.BurleyLeafItemItem;
import net.minecraft.item.ItemStack;
import java.util.List;
import net.minecraft.world.storage.loot.LootContext;
import net.minecraft.util.Direction;
import net.minecraft.world.IBlockReader;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.potion.Effects;
import net.minecraft.block.FlowerBlock;
import java.util.Iterator;
import net.minecraft.world.gen.feature.FlowersFeature;
import net.minecraft.world.gen.placement.IPlacementConfig;
import net.minecraft.world.gen.placement.FrequencyConfig;
import net.minecraft.world.gen.placement.Placement;
import net.minecraft.world.gen.blockplacer.BlockPlacer;
import net.minecraft.world.gen.blockstateprovider.BlockStateProvider;
import net.minecraft.world.gen.blockplacer.SimpleBlockPlacer;
import net.minecraft.world.gen.blockstateprovider.SimpleBlockStateProvider;
import net.minecraft.world.gen.GenerationStage;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.registries.IForgeRegistryEntry;
import net.minecraft.world.biome.Biome;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraft.world.gen.feature.IFeatureConfig;
import net.minecraft.world.dimension.DimensionType;
import net.minecraft.world.gen.ChunkGenerator;
import net.minecraft.world.IWorld;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import java.util.Random;
import java.util.function.Function;
import net.minecraft.world.gen.feature.DefaultFlowersFeature;
import net.minecraft.world.gen.feature.BlockClusterFeatureConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraft.client.renderer.RenderTypeLookup;
import net.minecraft.client.renderer.RenderType;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.Item;
import net.minecraft.item.BlockItem;
import net.minecraftforge.registries.ObjectHolder;
import net.minecraft.block.Block;
import net.mcreator.tobaccoproducts.SmokingmodModElements.ModElement;
import net.mcreator.tobaccoproducts.SmokingmodModElements;

@Tag
public class BurleyPlantBlock extends SmokingmodModElements.ModElement
{
    @ObjectHolder("smokingmod:burley_plant")
    public static final Block block;
    
    public BurleyPlantBlock(final SmokingmodModElements instance) {
        super(instance, 484);
    }
    
    @Override
    public void initElements() {
        this.elements.blocks.add(() -> new BlockCustomFlower());
        final BlockItem blockItem;
        this.elements.items.add(() -> {
            new BlockItem(BurleyPlantBlock.block, new Item.Properties().func_200916_a((ItemGroup)null));
            return (Item)blockItem.setRegistryName(BurleyPlantBlock.block.getRegistryName());
        });
    }
    
    @OnlyIn(Dist.CLIENT)
    @Override
    public void clientLoad(final FMLClientSetupEvent event) {
        RenderTypeLookup.setRenderLayer(BurleyPlantBlock.block, RenderType.func_228643_e_());
    }
    
    @Override
    public void init(final FMLCommonSetupEvent event) {
        final FlowersFeature feature = (FlowersFeature)new DefaultFlowersFeature(BlockClusterFeatureConfig::func_227300_a_) {
            public BlockState func_225562_b_(final Random random, final BlockPos bp, final BlockClusterFeatureConfig fc) {
                return BurleyPlantBlock.block.func_176223_P();
            }
            
            public boolean place(final IWorld world, final ChunkGenerator generator, final Random random, final BlockPos pos, final BlockClusterFeatureConfig config) {
                final DimensionType dimensionType = world.func_201675_m().func_186058_p();
                boolean dimensionCriteria = false;
                if (dimensionType == DimensionType.field_223227_a_) {
                    dimensionCriteria = true;
                }
                return dimensionCriteria && super.func_212245_a(world, generator, random, pos, (IFeatureConfig)config);
            }
        };
        for (final Biome biome : ForgeRegistries.BIOMES.getValues()) {
            boolean biomeCriteria = false;
            if (ForgeRegistries.BIOMES.getKey((IForgeRegistryEntry)biome).equals((Object)new ResourceLocation("jungle"))) {
                biomeCriteria = true;
            }
            if (ForgeRegistries.BIOMES.getKey((IForgeRegistryEntry)biome).equals((Object)new ResourceLocation("jungle_hills"))) {
                biomeCriteria = true;
            }
            if (!biomeCriteria) {
                continue;
            }
            biome.func_203611_a(GenerationStage.Decoration.VEGETAL_DECORATION, feature.func_225566_b_((IFeatureConfig)new BlockClusterFeatureConfig.Builder((BlockStateProvider)new SimpleBlockStateProvider(BurleyPlantBlock.block.func_176223_P()), (BlockPlacer)new SimpleBlockPlacer()).func_227315_a_(64).func_227322_d_()).func_227228_a_(Placement.field_215017_c.func_227446_a_((IPlacementConfig)new FrequencyConfig(1))));
        }
    }
    
    static {
        block = null;
    }
    
    public static class BlockCustomFlower extends FlowerBlock
    {
        public BlockCustomFlower() {
            super(Effects.field_76443_y, 0, Block.Properties.func_200945_a(Material.field_151585_k).func_200942_a().func_200947_a(SoundType.field_185849_b).func_200948_a(0.0f, 0.0f).func_200951_a(0));
            this.setRegistryName("burley_plant");
        }
        
        public int getFlammability(final BlockState state, final IBlockReader world, final BlockPos pos, final Direction face) {
            return 5;
        }
        
        public List<ItemStack> func_220076_a(final BlockState state, final LootContext.Builder builder) {
            final List<ItemStack> dropsOriginal = (List<ItemStack>)super.func_220076_a(state, builder);
            if (!dropsOriginal.isEmpty()) {
                return dropsOriginal;
            }
            return Collections.singletonList(new ItemStack((IItemProvider)BurleyLeafItemItem.block, 3));
        }
        
        public PlantType getPlantType(final IBlockReader world, final BlockPos pos) {
            return PlantType.Plains;
        }
    }
}
