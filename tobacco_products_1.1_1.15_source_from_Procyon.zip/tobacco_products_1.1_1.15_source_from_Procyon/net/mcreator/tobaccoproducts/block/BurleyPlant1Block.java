// 
// Decompiled by Procyon v0.5.36
// 

package net.mcreator.tobaccoproducts.block;

import net.minecraftforge.items.CapabilityItemHandler;
import net.minecraftforge.common.capabilities.Capability;
import javax.annotation.Nullable;
import java.util.stream.IntStream;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.container.ChestContainer;
import net.minecraft.inventory.container.Container;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.ITextComponent;
import java.util.Iterator;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.server.SUpdateTileEntityPacket;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.nbt.CompoundNBT;
import net.minecraftforge.items.wrapper.SidedInvWrapper;
import net.minecraft.util.Direction;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraft.util.NonNullList;
import net.minecraft.inventory.ISidedInventory;
import net.minecraft.tileentity.LockableLootTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.inventory.container.INamedContainerProvider;
import net.mcreator.tobaccoproducts.procedures.BurleyPlantGrowUpdateProcedure;
import java.util.HashMap;
import java.util.Random;
import net.minecraft.world.server.ServerWorld;
import net.minecraft.world.IWorldReader;
import net.minecraft.world.World;
import java.util.Collections;
import net.minecraft.util.IItemProvider;
import net.mcreator.tobaccoproducts.item.BurleySeedsItem;
import net.minecraft.item.ItemStack;
import java.util.List;
import net.minecraft.world.storage.loot.LootContext;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.block.BlockState;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraft.client.renderer.RenderTypeLookup;
import net.minecraft.client.renderer.RenderType;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import com.mojang.datafixers.types.Type;
import java.util.function.Supplier;
import net.minecraftforge.event.RegistryEvent;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.Item;
import net.minecraft.item.BlockItem;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraft.tileentity.TileEntityType;
import net.minecraftforge.registries.ObjectHolder;
import net.minecraft.block.Block;
import net.mcreator.tobaccoproducts.SmokingmodModElements.ModElement;
import net.mcreator.tobaccoproducts.SmokingmodModElements;

@Tag
public class BurleyPlant1Block extends SmokingmodModElements.ModElement
{
    @ObjectHolder("smokingmod:burley_plant_1")
    public static final Block block;
    @ObjectHolder("smokingmod:burley_plant_1")
    public static final TileEntityType<CustomTileEntity> tileEntityType;
    
    public BurleyPlant1Block(final SmokingmodModElements instance) {
        super(instance, 137);
        FMLJavaModLoadingContext.get().getModEventBus().register((Object)this);
    }
    
    @Override
    public void initElements() {
        this.elements.blocks.add(() -> new CustomBlock());
        final BlockItem blockItem;
        this.elements.items.add(() -> {
            new BlockItem(BurleyPlant1Block.block, new Item.Properties().func_200916_a((ItemGroup)null));
            return (Item)blockItem.setRegistryName(BurleyPlant1Block.block.getRegistryName());
        });
    }
    
    @SubscribeEvent
    public void registerTileEntity(final RegistryEvent.Register<TileEntityType<?>> event) {
        event.getRegistry().register(TileEntityType.Builder.func_223042_a((Supplier)CustomTileEntity::new, new Block[] { BurleyPlant1Block.block }).func_206865_a((Type)null).setRegistryName("burley_plant_1"));
    }
    
    @OnlyIn(Dist.CLIENT)
    @Override
    public void clientLoad(final FMLClientSetupEvent event) {
        RenderTypeLookup.setRenderLayer(BurleyPlant1Block.block, RenderType.func_228641_d_());
    }
    
    static {
        block = null;
        tileEntityType = null;
    }
    
    public static class CustomBlock extends Block
    {
        public CustomBlock() {
            super(Block.Properties.func_200945_a(Material.field_151581_o).func_200947_a(SoundType.field_185849_b).func_200948_a(1.0f, 10.0f).func_200951_a(0).func_226896_b_());
            this.setRegistryName("burley_plant_1");
        }
        
        public boolean func_220081_d(final BlockState state, final IBlockReader worldIn, final BlockPos pos) {
            return false;
        }
        
        public boolean func_200123_i(final BlockState state, final IBlockReader reader, final BlockPos pos) {
            return true;
        }
        
        public VoxelShape func_220053_a(final BlockState state, final IBlockReader world, final BlockPos pos, final ISelectionContext context) {
            return VoxelShapes.func_197873_a(0.0, 0.1, 0.0, 1.0, 1.0, 1.0);
        }
        
        public List<ItemStack> func_220076_a(final BlockState state, final LootContext.Builder builder) {
            final List<ItemStack> dropsOriginal = (List<ItemStack>)super.func_220076_a(state, builder);
            if (!dropsOriginal.isEmpty()) {
                return dropsOriginal;
            }
            return Collections.singletonList(new ItemStack((IItemProvider)BurleySeedsItem.block, 1));
        }
        
        public void func_220082_b(final BlockState state, final World world, final BlockPos pos, final BlockState oldState, final boolean moving) {
            super.func_220082_b(state, world, pos, oldState, moving);
            final int x = pos.func_177958_n();
            final int y = pos.func_177956_o();
            final int z = pos.func_177952_p();
            world.func_205220_G_().func_205360_a(new BlockPos(x, y, z), (Object)this, this.func_149738_a((IWorldReader)world));
        }
        
        public void func_225534_a_(final BlockState state, final ServerWorld world, final BlockPos pos, final Random random) {
            super.func_225534_a_(state, world, pos, random);
            final int x = pos.func_177958_n();
            final int y = pos.func_177956_o();
            final int z = pos.func_177952_p();
            final HashMap<String, Object> $_dependencies = new HashMap<String, Object>();
            $_dependencies.put("x", x);
            $_dependencies.put("y", y);
            $_dependencies.put("z", z);
            $_dependencies.put("world", world);
            BurleyPlantGrowUpdateProcedure.executeProcedure($_dependencies);
            world.func_205220_G_().func_205360_a(new BlockPos(x, y, z), (Object)this, this.func_149738_a((IWorldReader)world));
        }
        
        public INamedContainerProvider func_220052_b(final BlockState state, final World worldIn, final BlockPos pos) {
            final TileEntity tileEntity = worldIn.func_175625_s(pos);
            return (tileEntity instanceof INamedContainerProvider) ? tileEntity : null;
        }
        
        public boolean hasTileEntity(final BlockState state) {
            return true;
        }
        
        public TileEntity createTileEntity(final BlockState state, final IBlockReader world) {
            return (TileEntity)new CustomTileEntity();
        }
        
        public boolean func_189539_a(final BlockState state, final World world, final BlockPos pos, final int eventID, final int eventParam) {
            super.func_189539_a(state, world, pos, eventID, eventParam);
            final TileEntity tileentity = world.func_175625_s(pos);
            return tileentity != null && tileentity.func_145842_c(eventID, eventParam);
        }
    }
    
    public static class CustomTileEntity extends LockableLootTileEntity implements ISidedInventory
    {
        private NonNullList<ItemStack> stacks;
        private final LazyOptional<? extends IItemHandler>[] handlers;
        
        protected CustomTileEntity() {
            super((TileEntityType)BurleyPlant1Block.tileEntityType);
            this.stacks = (NonNullList<ItemStack>)NonNullList.func_191197_a(0, (Object)ItemStack.field_190927_a);
            this.handlers = (LazyOptional<? extends IItemHandler>[])SidedInvWrapper.create((ISidedInventory)this, Direction.values());
        }
        
        public void func_145839_a(final CompoundNBT compound) {
            super.func_145839_a(compound);
            if (!this.func_184283_b(compound)) {
                this.stacks = (NonNullList<ItemStack>)NonNullList.func_191197_a(this.func_70302_i_(), (Object)ItemStack.field_190927_a);
            }
            ItemStackHelper.func_191283_b(compound, (NonNullList)this.stacks);
        }
        
        public CompoundNBT func_189515_b(final CompoundNBT compound) {
            super.func_189515_b(compound);
            if (!this.func_184282_c(compound)) {
                ItemStackHelper.func_191282_a(compound, (NonNullList)this.stacks);
            }
            return compound;
        }
        
        public SUpdateTileEntityPacket func_189518_D_() {
            return new SUpdateTileEntityPacket(this.field_174879_c, 0, this.func_189517_E_());
        }
        
        public CompoundNBT func_189517_E_() {
            return this.func_189515_b(new CompoundNBT());
        }
        
        public void onDataPacket(final NetworkManager net, final SUpdateTileEntityPacket pkt) {
            this.func_145839_a(pkt.func_148857_g());
        }
        
        public int func_70302_i_() {
            return this.stacks.size();
        }
        
        public boolean func_191420_l() {
            for (final ItemStack itemstack : this.stacks) {
                if (!itemstack.func_190926_b()) {
                    return false;
                }
            }
            return true;
        }
        
        public ITextComponent func_213907_g() {
            return (ITextComponent)new StringTextComponent("burley_plant_1");
        }
        
        public int func_70297_j_() {
            return 64;
        }
        
        public Container func_213906_a(final int id, final PlayerInventory player) {
            return (Container)ChestContainer.func_216992_a(id, player, (IInventory)this);
        }
        
        public ITextComponent func_145748_c_() {
            return (ITextComponent)new StringTextComponent("BurleyPlant1");
        }
        
        protected NonNullList<ItemStack> func_190576_q() {
            return this.stacks;
        }
        
        protected void func_199721_a(final NonNullList<ItemStack> stacks) {
            this.stacks = stacks;
        }
        
        public boolean func_94041_b(final int index, final ItemStack stack) {
            return true;
        }
        
        public int[] func_180463_a(final Direction side) {
            return IntStream.range(0, this.func_70302_i_()).toArray();
        }
        
        public boolean func_180462_a(final int index, final ItemStack stack, @Nullable final Direction direction) {
            return this.func_94041_b(index, stack);
        }
        
        public boolean func_180461_b(final int index, final ItemStack stack, final Direction direction) {
            return true;
        }
        
        public <T> LazyOptional<T> getCapability(final Capability<T> capability, @Nullable final Direction facing) {
            if (!this.field_145846_f && facing != null && capability == CapabilityItemHandler.ITEM_HANDLER_CAPABILITY) {
                return (LazyOptional<T>)this.handlers[facing.ordinal()].cast();
            }
            return (LazyOptional<T>)super.getCapability((Capability)capability, facing);
        }
        
        public void func_145843_s() {
            super.func_145843_s();
            for (final LazyOptional<? extends IItemHandler> handler : this.handlers) {
                handler.invalidate();
            }
        }
    }
}
