// 
// Decompiled by Procyon v0.5.36
// 

package net.mcreator.tobaccoproducts.command;

import net.minecraft.world.World;
import net.minecraft.entity.Entity;
import net.mcreator.tobaccoproducts.procedures.ResetsmokelessCommandExecutedProcedure;
import java.util.Arrays;
import java.util.HashMap;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.arguments.ArgumentType;
import net.minecraft.command.Commands;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.command.CommandSource;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraftforge.fml.event.server.FMLServerStartingEvent;
import net.mcreator.tobaccoproducts.SmokingmodModElements.ModElement;
import net.mcreator.tobaccoproducts.SmokingmodModElements;

@Tag
public class ResetsmokelessCommand extends SmokingmodModElements.ModElement
{
    public ResetsmokelessCommand(final SmokingmodModElements instance) {
        super(instance, 480);
    }
    
    @Override
    public void serverLoad(final FMLServerStartingEvent event) {
        event.getCommandDispatcher().register((LiteralArgumentBuilder)this.customCommand());
    }
    
    private LiteralArgumentBuilder<CommandSource> customCommand() {
        return (LiteralArgumentBuilder<CommandSource>)((LiteralArgumentBuilder)LiteralArgumentBuilder.literal("resetsmokeless").then(Commands.func_197056_a("arguments", (ArgumentType)StringArgumentType.greedyString()).executes(this::execute))).executes(this::execute);
    }
    
    private int execute(final CommandContext<CommandSource> ctx) {
        final Entity entity = ((CommandSource)ctx.getSource()).func_197022_f();
        if (entity != null) {
            final int x = entity.func_180425_c().func_177958_n();
            final int y = entity.func_180425_c().func_177956_o();
            final int z = entity.func_180425_c().func_177952_p();
            final World world = entity.field_70170_p;
            final HashMap<String, String> cmdparams = new HashMap<String, String>();
            final int[] index = { -1 };
            final Object o;
            final HashMap<String, String> hashMap;
            final int n;
            Arrays.stream(ctx.getInput().split("\\s+")).forEach(param -> {
                if (o[0] >= 0) {
                    hashMap.put(Integer.toString(o[0]), param);
                }
                ++o[n];
                return;
            });
            final HashMap<String, Object> $_dependencies = new HashMap<String, Object>();
            $_dependencies.put("world", world);
            ResetsmokelessCommandExecutedProcedure.executeProcedure($_dependencies);
        }
        return 0;
    }
}
